@echo off
setlocal
cd /d "%~dp0"
title PSO.WOLKEN.PAGE - RAGOL LINK M1.4 DIAGNOSTIC
echo PSO.WOLKEN.PAGE - RAGOL LINK M1.4 DIAGNOSTIC START
echo.
echo This mode intentionally leaves PowerShell visible.
echo It opens the product UI without auto-reading the USB.
echo.
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RagolLink-App.ps1" -NoAutoStart
set "RC=%ERRORLEVEL%"
echo.
echo Ragol Link exited with code %RC%.
echo Startup log:
echo %LOCALAPPDATA%\JRPG.WORLD\RagolLink\logs\RAGOL_LINK_STARTUP.log
echo.
pause
