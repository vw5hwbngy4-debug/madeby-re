﻿$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

Add-Type -AssemblyName System.Windows.Forms

$installLog = Join-Path $env:TEMP "RAGOL_LINK_INSTALL.log"

function Show-InstallError([string]$Message) {
    [Windows.Forms.MessageBox]::Show(
        $Message,
        "Ragol Link installer",
        [Windows.Forms.MessageBoxButtons]::OK,
        [Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

try {
    ("[{0}] Installer started from {1}" -f (Get-Date -Format "s"), $PSScriptRoot) |
        Set-Content -LiteralPath $installLog -Encoding UTF8

    $source = $PSScriptRoot
    $target = Join-Path $env:LOCALAPPDATA "JRPG.WORLD\RagolLink"
    $desktop = [Environment]::GetFolderPath("Desktop")
    $programs = [Environment]::GetFolderPath("Programs")
    $startDir = Join-Path $programs "Wolken"

    $runtimeFiles = @(
        "Ragol-Link-USB.ps1",
        "RagolLink-Worker.ps1",
        "RagolLink-App.ps1",
        "RagolLink-Launcher.cs",
        "RagolLink.vbs",
        "VERSION.txt",
        "SECURITY.txt",
        "THIRD_PARTY_NOTICES.txt"
    )

    New-Item -ItemType Directory -Path $target -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $target "logs") -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $target "output") -Force | Out-Null
    New-Item -ItemType Directory -Path $startDir -Force | Out-Null

    foreach ($name in $runtimeFiles) {
        $src = Join-Path $source $name
        if (-not (Test-Path -LiteralPath $src)) {
            throw "Installer package is missing $name"
        }
        Copy-Item -LiteralPath $src -Destination (Join-Path $target $name) -Force
    }

    $exe = Join-Path $target "RagolLink.exe"
    $launcherSourcePath = Join-Path $target "RagolLink-Launcher.cs"
    $launcherSource = Get-Content -LiteralPath $launcherSourcePath -Raw
    $compiled = $false

    try {
        Remove-Item -LiteralPath $exe -Force -ErrorAction SilentlyContinue

        Add-Type `
            -TypeDefinition $launcherSource `
            -Language CSharp `
            -ReferencedAssemblies "System.dll","System.Windows.Forms.dll" `
            -OutputAssembly $exe `
            -OutputType WindowsApplication

        $compiled = Test-Path -LiteralPath $exe

        ("[{0}] Local EXE launcher compiled: {1}" -f
            (Get-Date -Format "s"), $compiled) |
            Add-Content -LiteralPath $installLog -Encoding UTF8
    }
    catch {
        $compiled = $false
        ("[{0}] EXE compile fallback: {1}" -f
            (Get-Date -Format "s"), $_.Exception.Message) |
            Add-Content -LiteralPath $installLog -Encoding UTF8
    }

    $wsh = New-Object -ComObject WScript.Shell

    function New-RagolShortcut([string]$Path) {
        $s = $wsh.CreateShortcut($Path)

        if ($compiled) {
            $s.TargetPath = $exe
            $s.WorkingDirectory = $target
        }
        else {
            $s.TargetPath = Join-Path $env:WINDIR "System32\wscript.exe"
            $vbsPath = Join-Path $target "RagolLink.vbs"
            $s.Arguments = '"' + $vbsPath + '"'
            $s.WorkingDirectory = $target
        }

        $s.Description = "Read an Original Xbox PSO save directly from USB and link it to pso.wolken.page."
        $s.Save()
    }

    New-RagolShortcut (Join-Path $desktop "Ragol Link.lnk")
    New-RagolShortcut (Join-Path $startDir "Ragol Link.lnk")
    # Remove only the previous Ragol Link Start menu shortcut; keep all other programs intact.
    Remove-Item -LiteralPath (Join-Path (Join-Path $programs "JRPG.WORLD") "Ragol Link.lnk") -Force -ErrorAction SilentlyContinue

    # Build the uninstaller without a PowerShell here-string.
    $uninstallLines = @(
        '$ErrorActionPreference = "SilentlyContinue"',
        '$desktop = [Environment]::GetFolderPath("Desktop")',
        '$programs = [Environment]::GetFolderPath("Programs")',
        'Remove-Item -LiteralPath (Join-Path $desktop "Ragol Link.lnk") -Force',
        'Remove-Item -LiteralPath (Join-Path (Join-Path $programs "JRPG.WORLD") "Ragol Link.lnk") -Force',
        'Remove-Item -LiteralPath (Join-Path (Join-Path $programs "Wolken") "Ragol Link.lnk") -Force',
        '$selfDir = Split-Path -Parent $PSCommandPath',
        '$quoted = $selfDir.Replace(''`"'',''``"'')',
        'Start-Process powershell.exe -WindowStyle Hidden -ArgumentList ("-NoProfile -Command `"Start-Sleep -Milliseconds 700; Remove-Item -LiteralPath ```"" + $quoted + "```" -Recurse -Force`"")'
    )
    $uninstallPath = Join-Path $target "Uninstall-RagolLink.ps1"
    Set-Content -LiteralPath $uninstallPath -Value $uninstallLines -Encoding UTF8

    ("[{0}] Install complete. Target={1}" -f
        (Get-Date -Format "s"), $target) |
        Add-Content -LiteralPath $installLog -Encoding UTF8

    $launcherMode = if ($compiled) {
        "RagolLink.exe was compiled locally."
    } else {
        "Windows could not compile the optional EXE launcher, so the shortcut uses the VBS launcher."
    }

    [Windows.Forms.MessageBox]::Show(
        "Ragol Link M1.4 is installed.`r`n`r`n" +
        "Desktop shortcut: Ragol Link`r`n" +
        $launcherMode + "`r`n`r`n" +
        "Plug in the Xbox-formatted USB and open Ragol Link.",
        "Ragol Link M1.4",
        [Windows.Forms.MessageBoxButtons]::OK,
        [Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}
catch {
    try {
        ("[{0}] INSTALL ERROR:`r`n{1}`r`nSTACK:`r`n{2}" -f
            (Get-Date -Format "s"),
            $_.Exception.ToString(),
            $_.ScriptStackTrace) |
            Add-Content -LiteralPath $installLog -Encoding UTF8
    } catch {}

    Show-InstallError(
        "Ragol Link could not be installed.`r`n`r`n" +
        $_.Exception.Message +
        "`r`n`r`nInstaller log:`r`n" +
        $installLog
    )
    exit 1
}
