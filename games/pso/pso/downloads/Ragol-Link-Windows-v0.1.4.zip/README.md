# Ragol Link

**Original Xbox PSO → live save truth**

Ragol Link is a Windows companion for **Phantasy Star Online Episode I & II on the Original Xbox**.

It reads `PSO_CHARACTER` directly from an Xbox-formatted USB using read-only raw disk access, validates the save locally, and hands the verified save to the live browser session at [PSO on Wolken](https://pso.wolken.page/pso/) through a temporary localhost bridge.

No FATXplorer mount. No ZIP export. No file picker in the normal flow. The raw save stays on the PC.

> **First known direct Original Xbox PSO USB-to-browser save bridge.**
>
> This is a best-effort prior-art claim based on public research, not an absolute guarantee that no unpublished or obscure historical implementation ever existed.

## Quick start

1. Download **Ragol-Link-Windows.zip** from the latest GitHub Release.
2. Extract it.
3. Run **`INSTALL RAGOL LINK.cmd`**.
4. Plug in the Xbox-formatted USB containing the PSO save.
5. Open **Ragol Link** from Desktop or Start.
6. Accept Windows UAC.
7. Ragol Link reads the USB, validates the character, opens `pso.wolken.page/pso/`, and links the save automatically.
8. If Chrome asks whether PSO.WOLKEN.PAGE may access localhost / the local network, choose **Allow**.

Permanent latest download:

`https://github.com/vw5hwbngy4-debug/Ragol-Link/releases/latest/download/Ragol-Link-Windows.zip`

## Architecture

```text
Original Xbox
    ↓
Xbox-formatted USB
    ↓
Windows PhysicalDrive · GENERIC_READ only
    ↓
FATX
    ↓
4d53004a/.../PSO_CHARACTER
    ↓
PSO V2 decrypt + CRC + structure validation
    ↓
temporary 127.0.0.1 bridge
    ↓
pso.wolken.page/pso/
    ↓
verified character context for Rico
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Privacy and safety

- Raw USB access is **read-only**.
- No FATX mount, format, repair, or filesystem write.
- `PSO_CHARACTER` is validated locally.
- Localhost bridge binds only to `127.0.0.1`.
- Random ephemeral port + one-time token.
- Browser origin restricted to PSO.WOLKEN.PAGE.
- Bridge closes after confirmation or timeout.
- The raw save is not uploaded to Rico by the bridge.

See [SECURITY.md](SECURITY.md).

## Proven real-hardware path

Original M1.3 passed end-to-end on real Original Xbox save hardware (historical result; v0.1.4 requires retest):

- raw USB read: **PASS**
- logical sector size: **512 bytes**
- FATX: **FAT32**
- real data cluster: **16 KiB**
- data offset: **`0x7A000`**
- PSO chain: **`8 → 9 → 10 → 11 → EOF`**
- `PSO_CHARACTER`: **65,536 bytes**
- PSO decrypt / CRC / signature validation: **PASS**
- byte-identical parity with an independent FATXplorer export: **PASS**
- localhost bridge: **PASS**
- browser confirmation + automatic bridge shutdown: **PASS**

The private test-save fingerprint is intentionally not published.

See [docs/REAL_HARDWARE_PROOF.md](docs/REAL_HARDWARE_PROOF.md).

## Requirements

- Windows 11 tested
- Windows PowerShell 5.1
- Administrator elevation for raw physical-disk access
- Original Xbox PSO Episode I & II save on an Xbox-formatted USB
- Chrome/Chromium recommended

## Scope

Current scope is deliberately narrow:

- Original Xbox
- Phantasy Star Online Episode I & II
- `PSO_CHARACTER`
- Windows companion
- PSO.WOLKEN.PAGE `/pso/`

GameCube and Blue Burst are not product targets in this release.

## Portable mode

Use:

`Run Ragol Link Portable.cmd`

## Diagnostics

If the normal GUI does not start:

`DIAGNOSTIC START.cmd`

Installed logs:

`%LOCALAPPDATA%\JRPG.WORLD\RagolLink\logs\RAGOL_LINK_LAST_RUN.log`

Startup log:

`%LOCALAPPDATA%\JRPG.WORLD\RagolLink\logs\RAGOL_LINK_STARTUP.log`

## License

GPL-3.0-or-later.

See [LICENSE](LICENSE) and [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt).

## PSO.WOLKEN.PAGE

**https://pso.wolken.page/pso/**

## v0.1.4 migration note

This build changes the website to https://pso.wolken.page/pso/ and only allows `https://pso.wolken.page` at the local bridge. Install over M1.3: its legacy `%LOCALAPPDATA%\JRPG.WORLD\RagolLink` folder is intentionally reused, preserving logs and the existing desktop shortcut. The Start shortcut moves into the Wolken program group. M1.4 has **not** yet been hardware-tested. Install the companion and the PSO website hotfix together.
