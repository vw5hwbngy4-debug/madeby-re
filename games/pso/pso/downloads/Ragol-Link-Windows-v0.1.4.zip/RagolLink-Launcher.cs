using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        try
        {
            string dir = AppDomain.CurrentDomain.BaseDirectory;
            string script = Path.Combine(dir, "RagolLink-App.ps1");

            if (!File.Exists(script))
            {
                MessageBox.Show(
                    "RagolLink-App.ps1 is missing.\r\n\r\nReinstall Ragol Link.",
                    "Ragol Link",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
                return;
            }

            var psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + script + "\"",
                WorkingDirectory = dir,
                UseShellExecute = true,
                Verb = "runas",
                WindowStyle = ProcessWindowStyle.Hidden
            };

            Process.Start(psi);
        }
        catch (System.ComponentModel.Win32Exception ex) when (ex.NativeErrorCode == 1223)
        {
            // UAC cancelled by the user. Nothing else to do.
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "Ragol Link",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
        }
    }
}
