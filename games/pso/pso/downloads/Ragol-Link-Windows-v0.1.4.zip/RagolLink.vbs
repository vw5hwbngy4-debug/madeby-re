Option Explicit
Dim shell, fso, here, ps, args
Set shell = CreateObject("Shell.Application")
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)
ps = "powershell.exe"
args = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & here & "\RagolLink-App.ps1"""
shell.ShellExecute ps, args, here, "runas", 0
