# Ragol Link v0.1.4 · PSO on Wolken

Migration release: https://pso.wolken.page/pso/

- The Windows application opens the new PSO page automatically and via the website button.
- The temporary localhost bridge accepts only the exact origin `https://pso.wolken.page`, not jrpg.world.
- Read-only USB extraction, PSO_CHARACTER validation, random token and localhost endpoints are unchanged.
- In-place install intentionally reuses `%LOCALAPPDATA%\JRPG.WORLD\RagolLink` to preserve existing installation and logs.
- In addition to updating Windows, install the website hotfix to replace the download, browser bridge error text, and release link.

This ZIP distributes PowerShell source and an installer. It does not include a prebuilt/signed .exe: the installer attempts to compile a launcher on the user's Windows PC and falls back to VBS.

**Verification:** ZIP integrity and static checks only. Windows 11 and original Xbox hardware end-to-end not retested for v0.1.4. The M1.3 proof in docs is historical.
