@echo off
setlocal
set "APP=%LOCALAPPDATA%\JRPG.WORLD\RagolLink"
if not exist "%APP%\Uninstall-RagolLink.ps1" (
  echo Ragol Link is not installed in the expected location.
  pause
  exit /b 1
)
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%APP%\Uninstall-RagolLink.ps1"
