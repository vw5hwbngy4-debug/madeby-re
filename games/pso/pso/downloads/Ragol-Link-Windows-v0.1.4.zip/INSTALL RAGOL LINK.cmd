@echo off
setlocal
cd /d "%~dp0"
title PSO.WOLKEN.PAGE - RAGOL LINK M1.4 INSTALLER
echo PSO.WOLKEN.PAGE - RAGOL LINK M1.4 INSTALLER
echo.
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-RagolLink.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo Installation failed with exit code %RC%.
  echo Log: %TEMP%\RAGOL_LINK_INSTALL.log
  echo.
  pause
  exit /b %RC%
)
exit /b 0
