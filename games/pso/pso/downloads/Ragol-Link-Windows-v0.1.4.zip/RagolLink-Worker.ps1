﻿param(
    [Parameter(Mandatory=$true)]
    [string]$LogPath
)

$ErrorActionPreference = "Continue"
Set-StrictMode -Version Latest

$dir = Split-Path -Parent $LogPath
if (-not (Test-Path -LiteralPath $dir)) {
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
}

try {
    Start-Transcript -Path $LogPath -Force | Out-Null
} catch {}

$code = 1
try {
    & (Join-Path $PSScriptRoot "Ragol-Link-USB.ps1")
    if ($null -ne $global:LASTEXITCODE) {
        $code = [int]$global:LASTEXITCODE
    } else {
        $code = 0
    }
}
catch {
    Write-Host ""
    Write-Host "UNHANDLED RAGOL LINK WORKER ERROR" -ForegroundColor Red
    Write-Host $_.Exception.ToString() -ForegroundColor Red
    if ($_.ScriptStackTrace) {
        Write-Host ""
        Write-Host "Script stack:" -ForegroundColor DarkGray
        Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    }
    $code = 1
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
}

exit $code
