﻿param(
    [switch]$NoAutoStart
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$script:StartupLog = Join-Path $env:LOCALAPPDATA "JRPG.WORLD\RagolLink\logs\RAGOL_LINK_STARTUP.log"
try {
    $startupDir = Split-Path -Parent $script:StartupLog
    New-Item -ItemType Directory -Path $startupDir -Force | Out-Null
    ("[{0}] Ragol Link GUI starting from {1}" -f (Get-Date -Format "s"), $PSScriptRoot) |
        Add-Content -LiteralPath $script:StartupLog -Encoding UTF8
} catch {}

function Write-RagolUiError([string]$Where, $ErrorRecord) {
    try {
        $detail = if ($null -ne $ErrorRecord) { $ErrorRecord.Exception.ToString() } else { "Unknown error" }
        $stack = if ($null -ne $ErrorRecord -and $ErrorRecord.ScriptStackTrace) { $ErrorRecord.ScriptStackTrace } else { "" }
        ("[{0}] UI ERROR at {1}: {2}`r`n{3}" -f
            (Get-Date -Format "s"), $Where, $detail, $stack) |
            Add-Content -LiteralPath $script:StartupLog -Encoding UTF8
    } catch {}
}

function Test-RagolAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Portable mode also gets one-click elevation.
if (-not (Test-RagolAdmin)) {
    $args = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-WindowStyle", "Hidden",
        "-File", "`"$PSCommandPath`""
    )
    if ($NoAutoStart) { $args += "-NoAutoStart" }

    try {
        Start-Process -FilePath "powershell.exe" -Verb RunAs -WindowStyle Hidden `
            -WorkingDirectory $PSScriptRoot -ArgumentList ($args -join " ")
    } catch {}
    exit
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$xaml = @'
<Window
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    Title="Ragol Link"
    Width="560"
    Height="410"
    WindowStartupLocation="CenterScreen"
    ResizeMode="NoResize"
    Background="#08111C"
    Foreground="#EEF7FF">
  <Grid Margin="26">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="20"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>

    <StackPanel Grid.Row="0">
      <TextBlock Text="JRPG.WORLD" FontSize="12" FontWeight="Bold"
                 Foreground="#7BC7FF"/>
      <TextBlock Text="RAGOL LINK" FontSize="31" FontWeight="Bold"
                 Margin="0,3,0,0"/>
      <TextBlock Text="Original Xbox PSO → live save truth"
                 FontSize="14" Foreground="#9FB3C7" Margin="0,3,0,0"/>
    </StackPanel>

    <Border Grid.Row="2" CornerRadius="16" Background="#0D1B2B"
            BorderBrush="#20364B" BorderThickness="1" Padding="22">
      <Grid>
        <Grid.RowDefinitions>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="18"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <StackPanel Orientation="Horizontal">
          <Ellipse x:Name="StatusDot" Width="12" Height="12"
                   Fill="#5F7181" Margin="0,3,10,0"/>
          <TextBlock x:Name="StatusTitle" Text="Ready"
                     FontSize="19" FontWeight="SemiBold"/>
        </StackPanel>

        <TextBlock x:Name="StatusDetail" Grid.Row="1"
                   Text="Plug in the Xbox-formatted USB. Ragol Link only reads it."
                   Foreground="#B7C7D8" FontSize="13" TextWrapping="Wrap"
                   Margin="22,9,0,0" MaxWidth="450"/>

        <ProgressBar x:Name="Progress" Grid.Row="2" Height="5"
                     Margin="0,20,0,0" IsIndeterminate="False"
                     Minimum="0" Maximum="100" Value="0"/>

        <StackPanel Grid.Row="4" Orientation="Horizontal">
          <Button x:Name="ReadButton" Content="READ XBOX USB"
                  Height="40" MinWidth="150" Padding="18,0"
                  FontWeight="Bold" Cursor="Hand"/>
          <Button x:Name="SiteButton" Content="JRPG.WORLD / PSO"
                  Height="40" Margin="10,0,0,0" Padding="14,0"
                  Cursor="Hand"/>
          <Button x:Name="LogButton" Content="LOG"
                  Height="40" Margin="10,0,0,0" Padding="14,0"
                  Cursor="Hand"/>
        </StackPanel>
      </Grid>
    </Border>

    <Grid Grid.Row="3" Margin="0,18,0,0">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="*"/>
        <ColumnDefinition Width="Auto"/>
      </Grid.ColumnDefinitions>
      <TextBlock Text="READ-ONLY · ORIGINAL XBOX · LOCALHOST BRIDGE"
                 FontSize="10" Foreground="#63788D" VerticalAlignment="Center"/>
      <TextBlock Grid.Column="1" Text="M1 · 0.1.0"
                 FontSize="10" Foreground="#63788D" VerticalAlignment="Center"/>
    </Grid>
  </Grid>
</Window>
'@

try {
    $xml = New-Object Xml.XmlDocument
    $xml.LoadXml($xaml)
    $reader = New-Object Xml.XmlNodeReader($xml)
    $window = [Windows.Markup.XamlReader]::Load($reader)
}
catch {
    $msg = "Ragol Link could not open its window.`r`n`r`n" + $_.Exception.Message +
           "`r`n`r`nStartup log:`r`n" + $script:StartupLog
    try {
        ("[{0}] GUI/XAML ERROR: {1}`r`n{2}" -f (Get-Date -Format "s"),
            $_.Exception.ToString(), $_.ScriptStackTrace) |
            Add-Content -LiteralPath $script:StartupLog -Encoding UTF8
    } catch {}
    [Windows.MessageBox]::Show(
        $msg,
        "Ragol Link startup error",
        [Windows.MessageBoxButton]::OK,
        [Windows.MessageBoxImage]::Error
    ) | Out-Null
    exit 1
}

$StatusDot = $window.FindName("StatusDot")
$StatusTitle = $window.FindName("StatusTitle")
$StatusDetail = $window.FindName("StatusDetail")
$Progress = $window.FindName("Progress")
$ReadButton = $window.FindName("ReadButton")
$SiteButton = $window.FindName("SiteButton")
$LogButton = $window.FindName("LogButton")

$brushConverter = New-Object Windows.Media.BrushConverter
function Get-Brush([string]$hex) { return $brushConverter.ConvertFromString($hex) }

$logsDir = Join-Path $PSScriptRoot "logs"
if (-not (Test-Path -LiteralPath $logsDir)) {
    New-Item -ItemType Directory -Path $logsDir -Force | Out-Null
}
$script:currentLog = Join-Path $logsDir "RAGOL_LINK_LAST_RUN.log"
$script:workerProcess = $null
$script:running = $false
$script:lastText = ""

function Set-State([string]$Title, [string]$Detail, [string]$Color, [bool]$Busy, [int]$Percent = 0) {
    $StatusTitle.Text = $Title
    $StatusDetail.Text = $Detail
    $StatusDot.Fill = Get-Brush $Color
    $Progress.IsIndeterminate = $Busy
    if (-not $Busy) { $Progress.Value = $Percent }
}

function Open-Log {
    if (Test-Path -LiteralPath $script:currentLog) {
        Start-Process notepad.exe -ArgumentList "`"$script:currentLog`""
    } else {
        [Windows.MessageBox]::Show(
            "No run log exists yet.",
            "Ragol Link",
            [Windows.MessageBoxButton]::OK,
            [Windows.MessageBoxImage]::Information
        ) | Out-Null
    }
}

function Start-RagolRead {
    if ($script:running) { return }

    $script:running = $true
    $script:lastText = ""
    $ReadButton.IsEnabled = $false
    $ReadButton.Content = "READING…"

    try { Remove-Item -LiteralPath $script:currentLog -Force -ErrorAction SilentlyContinue } catch {}

    Set-State "Looking for your Xbox USB…" `
        "Ragol Link is scanning USB physical disks read-only. It will ignore non-Xbox drives." `
        "#7BC7FF" $true

    $worker = Join-Path $PSScriptRoot "RagolLink-Worker.ps1"
    $argList = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-WindowStyle", "Hidden",
        "-File", "`"$worker`"",
        "-LogPath", "`"$script:currentLog`""
    )

    try {
        $script:workerProcess = Start-Process -FilePath "powershell.exe" `
            -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru `
            -ArgumentList ($argList -join " ")
    }
    catch {
        $script:running = $false
        $ReadButton.IsEnabled = $true
        $ReadButton.Content = "TRY AGAIN"
        Set-State "Could not start Ragol Link" $_.Exception.Message "#FF7F97" $false 0
    }
}

$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(250)
$timer.Add_Tick({
    try {
        if (-not $script:running) { return }

        $text = ""
        try {
            if (Test-Path -LiteralPath $script:currentLog) {
                $text = [IO.File]::ReadAllText($script:currentLog)
            }
        } catch {}

        if ($text -ne $script:lastText) {
            $script:lastText = $text

            if ($text -match "PSO validator: PASS") {
                Set-State "Verified PSO save found" `
                    "The Xbox character passed PSO decrypt, CRC and signature validation." `
                    "#67E8A5" $true
            }

            if ($text -match "RAGOL LINK LOCALHOST BRIDGE READY") {
                Set-State "Opening JRPG.WORLD…" `
                    "A temporary localhost bridge is handing the verified save to your browser. If Chrome asks for local-network access, choose Allow." `
                    "#BFA7FF" $true
            }

            if ($text -match "\[BRIDGE\] jrpg\.world connected") {
                Set-State "JRPG.WORLD connected" `
                    "Your browser reached the local bridge. The raw save stays on this PC." `
                    "#BFA7FF" $true
            }

            if ($text -match "\[BRIDGE\] PSO_CHARACTER handed") {
                Set-State "Linking your character…" `
                    "JRPG.WORLD is validating and decoding the local Xbox save now." `
                    "#BFA7FF" $true
            }

            if ($text -match "\[BRIDGE\] Browser confirmed the verified save is linked") {
                Set-State "Linked to JRPG.WORLD ✓" `
                    "Rico now has your verified Original Xbox PSO character as live browser context." `
                    "#67E8A5" $false 100
                $ReadButton.Content = "READ AGAIN"
            }

            if ($text -match "RAGOL LINK could not extract a save") {
                $detail = "No validated Original Xbox PSO save was found. Check that the Xbox-formatted USB is plugged in, then try again."
                if ($text -match "No USB physical disks were detected") {
                    $detail = "Windows does not currently see a USB disk. Plug in the Xbox-formatted USB and try again."
                }
                Set-State "Xbox PSO save not found" $detail "#FF7F97" $false 0
                $ReadButton.Content = "TRY AGAIN"
            }

            if ($text -match "Localhost bridge failed|Timed out before the browser confirmed linking") {
                Set-State "Browser link needs attention" `
                    "The save was extracted safely, but the browser did not confirm localhost linking. Allow local-network access for jrpg.world or use the manual PSO_CHARACTER fallback." `
                    "#FFCF70" $false 70
                $ReadButton.Content = "TRY AGAIN"
            }
        }

        if ($null -ne $script:workerProcess -and $script:workerProcess.HasExited) {
            $script:running = $false
            $ReadButton.IsEnabled = $true

            if ($StatusTitle.Text -eq "Linked to JRPG.WORLD ✓") {
                $ReadButton.Content = "READ AGAIN"
            }
            elseif ($StatusTitle.Text -notmatch "not found|attention|Could not") {
                if ($script:workerProcess.ExitCode -eq 0) {
                    Set-State "Linked to JRPG.WORLD ✓" `
                        "The verified Xbox save was handed to JRPG.WORLD successfully. You can close Ragol Link or read again." `
                        "#67E8A5" $false 100
                    $ReadButton.Content = "READ AGAIN"
                } else {
                    Set-State "Ragol Link needs attention" `
                        "The run did not complete. Open LOG for the exact diagnostic." `
                        "#FF7F97" $false 0
                    $ReadButton.Content = "TRY AGAIN"
                }
            }
        }
    }
    catch {
        Write-RagolUiError "poll timer" $_
        $script:running = $false
        try {
            $ReadButton.IsEnabled = $true
            $ReadButton.Content = "TRY AGAIN"
            Set-State "Ragol Link UI recovered" `
                "The background read may still have completed. The window was kept open. Open LOG for details or try again." `
                "#FFCF70" $false 0
        } catch {}
    }
})
$timer.Start()

$ReadButton.Add_Click({
    try { Start-RagolRead }
    catch {
        Write-RagolUiError "READ XBOX USB button" $_
        Set-State "Could not start read" $_.Exception.Message "#FF7F97" $false 0
    }
})
$SiteButton.Add_Click({
    try { Start-Process "https://jrpg.world/pso/" }
    catch {
        Write-RagolUiError "JRPG.WORLD button" $_
        Set-State "Could not open browser" $_.Exception.Message "#FFCF70" $false 0
    }
})
$LogButton.Add_Click({
    try { Open-Log }
    catch {
        Write-RagolUiError "LOG button" $_
        Set-State "Could not open log" $_.Exception.Message "#FFCF70" $false 0
    }
})

$window.Add_Closed({
    try {
        $timer.Stop()
    } catch {}
})

$script:autoStarted = $false
$window.Add_ContentRendered({
    try {
        if (-not $NoAutoStart -and -not $script:autoStarted) {
            $script:autoStarted = $true
            Start-RagolRead
        }
    }
    catch {
        Write-RagolUiError "automatic start" $_
        try {
            $script:running = $false
            $ReadButton.IsEnabled = $true
            $ReadButton.Content = "TRY AGAIN"
            Set-State "Could not auto-start" `
                "The Ragol Link window is staying open. Press READ XBOX USB to retry, or open LOG for details." `
                "#FFCF70" $false 0
        } catch {}
    }
})

try {
    [void]$window.ShowDialog()
}
catch {
    Write-RagolUiError "ShowDialog" $_
    try {
        [Windows.MessageBox]::Show(
            "Ragol Link hit a UI error, but the background Xbox read may still have completed.`r`n`r`n" +
            $_.Exception.Message +
            "`r`n`r`nLog:`r`n" + $script:StartupLog,
            "Ragol Link UI error",
            [Windows.MessageBoxButton]::OK,
            [Windows.MessageBoxImage]::Error
        ) | Out-Null
    } catch {}
    exit 1
}
