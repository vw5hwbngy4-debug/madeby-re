﻿param(
    [string]$DevicePath,
    [string]$ImagePath,
    [string]$OutputDirectory = (Join-Path $PSScriptRoot "output"),
    [switch]$NoLaunch,
    [switch]$VerboseScan
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$TitleId = "4d53004a"
$TargetFile = "PSO_CHARACTER"
$ExpectedCharacterSize = 65536
$script:Fat16ReservedStart = [uint64]65520       # 0xFFF0
$script:Fat32ReservedStart = [uint64]4294967280  # 0xFFFFFFF0
$FatxSignature = [Text.Encoding]::ASCII.GetBytes("FATX")

function Write-Status([string]$Text) {
    Write-Host "[RAGOL LINK] $Text"
}

function Test-IsAdministrator {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

Add-Type -TypeDefinition @"
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

public static class RagolRawDisk
{
    const uint GENERIC_READ = 0x80000000;
    const uint FILE_SHARE_READ = 0x00000001;
    const uint FILE_SHARE_WRITE = 0x00000002;
    const uint OPEN_EXISTING = 3;
    const uint FILE_ATTRIBUTE_NORMAL = 0x00000080;
    const uint FILE_FLAG_NO_BUFFERING = 0x20000000;
    const uint FILE_BEGIN = 0;
    const uint IOCTL_DISK_GET_LENGTH_INFO = 0x0007405C;
    const uint IOCTL_DISK_GET_DRIVE_GEOMETRY = 0x00070000;

    const uint MEM_COMMIT = 0x1000;
    const uint MEM_RESERVE = 0x2000;
    const uint MEM_RELEASE = 0x8000;
    const uint PAGE_READWRITE = 0x04;

    [StructLayout(LayoutKind.Sequential)]
    public struct DISK_GEOMETRY {
        public long Cylinders;
        public int MediaType;
        public int TracksPerCylinder;
        public int SectorsPerTrack;
        public int BytesPerSector;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern SafeFileHandle CreateFileW(
        string lpFileName,
        uint dwDesiredAccess,
        uint dwShareMode,
        IntPtr lpSecurityAttributes,
        uint dwCreationDisposition,
        uint dwFlagsAndAttributes,
        IntPtr hTemplateFile);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool SetFilePointerEx(
        SafeFileHandle hFile,
        long liDistanceToMove,
        out long lpNewFilePointer,
        uint dwMoveMethod);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool ReadFile(
        SafeFileHandle hFile,
        IntPtr lpBuffer,
        uint nNumberOfBytesToRead,
        out uint lpNumberOfBytesRead,
        IntPtr lpOverlapped);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool DeviceIoControl(
        SafeFileHandle hDevice,
        uint dwIoControlCode,
        IntPtr lpInBuffer,
        uint nInBufferSize,
        out long lpOutBuffer,
        uint nOutBufferSize,
        out uint lpBytesReturned,
        IntPtr lpOverlapped);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool DeviceIoControl(
        SafeFileHandle hDevice,
        uint dwIoControlCode,
        IntPtr lpInBuffer,
        uint nInBufferSize,
        out DISK_GEOMETRY lpOutBuffer,
        uint nOutBufferSize,
        out uint lpBytesReturned,
        IntPtr lpOverlapped);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr VirtualAlloc(
        IntPtr lpAddress,
        UIntPtr dwSize,
        uint flAllocationType,
        uint flProtect);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool VirtualFree(
        IntPtr lpAddress,
        UIntPtr dwSize,
        uint dwFreeType);

    static Win32Exception LastWin32(string prefix)
    {
        int e = Marshal.GetLastWin32Error();
        return new Win32Exception(e, prefix + " (Win32 error " + e + ")");
    }

    public static SafeFileHandle OpenReadOnly(string path)
    {
        // FILE_FLAG_NO_BUFFERING makes raw-disk semantics explicit.
        // ReadAtAligned handles all required alignment internally.
        SafeFileHandle h = CreateFileW(
            path,
            GENERIC_READ,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            IntPtr.Zero,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL | FILE_FLAG_NO_BUFFERING,
            IntPtr.Zero);

        if (h.IsInvalid)
            throw LastWin32("Could not open raw device read-only: " + path);
        return h;
    }

    public static int GetBytesPerSector(SafeFileHandle h)
    {
        DISK_GEOMETRY g;
        uint returned;
        if (!DeviceIoControl(
            h,
            IOCTL_DISK_GET_DRIVE_GEOMETRY,
            IntPtr.Zero,
            0,
            out g,
            (uint)Marshal.SizeOf(typeof(DISK_GEOMETRY)),
            out returned,
            IntPtr.Zero))
            throw LastWin32("IOCTL_DISK_GET_DRIVE_GEOMETRY failed");

        if (g.BytesPerSector <= 0)
            throw new InvalidOperationException("Disk reported invalid BytesPerSector");
        return g.BytesPerSector;
    }

    public static long GetLength(SafeFileHandle h)
    {
        long length;
        uint returned;
        if (!DeviceIoControl(
            h,
            IOCTL_DISK_GET_LENGTH_INFO,
            IntPtr.Zero,
            0,
            out length,
            8,
            out returned,
            IntPtr.Zero))
            throw LastWin32("IOCTL_DISK_GET_LENGTH_INFO failed");
        return length;
    }

    public static byte[] ReadAtAligned(SafeFileHandle h, long offset, int count, int sectorSize)
    {
        if (offset < 0) throw new ArgumentOutOfRangeException("offset");
        if (count < 0) throw new ArgumentOutOfRangeException("count");
        if (count == 0) return new byte[0];
        if (sectorSize <= 0) throw new ArgumentOutOfRangeException("sectorSize");

        long alignedOffset = offset - (offset % sectorSize);
        long end = checked(offset + count);
        long alignedEnd = ((end + sectorSize - 1) / sectorSize) * sectorSize;
        int alignedCount = checked((int)(alignedEnd - alignedOffset));

        long pos;
        if (!SetFilePointerEx(h, alignedOffset, out pos, FILE_BEGIN))
            throw LastWin32("SetFilePointerEx failed");

        IntPtr native = VirtualAlloc(
            IntPtr.Zero,
            (UIntPtr)(ulong)alignedCount,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_READWRITE);
        if (native == IntPtr.Zero)
            throw LastWin32("VirtualAlloc failed");

        try {
            uint read;
            if (!ReadFile(h, native, (uint)alignedCount, out read, IntPtr.Zero))
                throw LastWin32(
                    "ReadFile failed at aligned offset " + alignedOffset +
                    " length " + alignedCount +
                    " sector " + sectorSize);

            if (read < alignedCount)
                throw new System.IO.EndOfStreamException(
                    "Short raw-device read: requested " + alignedCount +
                    " bytes, received " + read);

            byte[] aligned = new byte[alignedCount];
            Marshal.Copy(native, aligned, 0, alignedCount);

            int sliceStart = checked((int)(offset - alignedOffset));
            byte[] result = new byte[count];
            Buffer.BlockCopy(aligned, sliceStart, result, 0, count);
            return result;
        }
        finally {
            VirtualFree(native, UIntPtr.Zero, MEM_RELEASE);
        }
    }
}
"@

Add-Type -TypeDefinition @"
using System;
using System.IO;
using System.Security.Cryptography;

public static class RagolPsoValidator
{
    const int FILE_SIZE = 0x10000;
    const int HEADER = 0x6048;
    const int PAYLOAD_SIZE = 0x28E8;
    const int SEED_OFF = 0x28E4;
    const int CHAR = 4;
    const uint SIG = 0xC87ED5B1u;

    static uint U32(byte[] b, int o)
    {
        return (uint)(b[o] | (b[o+1] << 8) | (b[o+2] << 16) | (b[o+3] << 24));
    }

    static uint[] BuildCrcTable()
    {
        uint[] t = new uint[256];
        for (uint n = 0; n < 256; n++)
        {
            uint c = n;
            for (int k = 0; k < 8; k++)
                c = ((c & 1) != 0) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
            t[n] = c;
        }
        return t;
    }

    static readonly uint[] CrcTable = BuildCrcTable();

    static uint Crc32(byte[] data)
    {
        uint c = 0xFFFFFFFFu;
        for (int i = 0; i < data.Length; i++)
            c = CrcTable[(c ^ data[i]) & 0xFF] ^ (c >> 8);
        return c ^ 0xFFFFFFFFu;
    }

    sealed class PsoV2
    {
        readonly uint[] s = new uint[0x39];
        int o;

        public PsoV2(uint seed)
        {
            uint a = 1, b = seed;
            s[0x37] = b;
            for (int vi = 0x15; vi <= 0x36 * 0x15; vi += 0x15)
            {
                s[vi % 0x37] = a;
                uint c = unchecked(b - a);
                b = a;
                a = c;
            }
            for (int i = 0; i < 5; i++) Update();
        }

        void Update()
        {
            for (int z = 1; z < 0x19; z++)
                s[z] = unchecked(s[z] - s[z + 0x1F]);
            for (int z = 0x19; z < 0x38; z++)
                s[z] = unchecked(s[z] - s[z - 0x18]);
            o = 1;
        }

        uint Next()
        {
            if (o == 0x38) Update();
            return s[o++];
        }

        public byte[] CryptLE(byte[] input)
        {
            byte[] output = (byte[])input.Clone();
            int words = output.Length / 4;
            for (int i = 0; i < words; i++)
            {
                int p = i * 4;
                uint v = U32(output, p) ^ Next();
                output[p] = (byte)v;
                output[p+1] = (byte)(v >> 8);
                output[p+2] = (byte)(v >> 16);
                output[p+3] = (byte)(v >> 24);
            }
            int extra = output.Length % 4;
            if (extra != 0)
            {
                int p = words * 4;
                byte[] tmp = new byte[4];
                Buffer.BlockCopy(output, p, tmp, 0, extra);
                uint v = U32(tmp, 0) ^ Next();
                tmp[0] = (byte)v;
                tmp[1] = (byte)(v >> 8);
                tmp[2] = (byte)(v >> 16);
                tmp[3] = (byte)(v >> 24);
                Buffer.BlockCopy(tmp, 0, output, p, extra);
            }
            return output;
        }
    }

    public static string Sha256(byte[] data)
    {
        using (var sha = SHA256.Create())
        {
            byte[] h = sha.ComputeHash(data);
            return BitConverter.ToString(h).Replace("-", "").ToLowerInvariant();
        }
    }

    public static string Validate(byte[] src)
    {
        try
        {
            if (src == null || src.Length != FILE_SIZE)
                return "FAIL:file_size";

            uint sourceSize = U32(src, 0x14);
            if (sourceSize != (uint)(src.Length - 0x4000))
                return "FAIL:source_size";

            uint dataSize = U32(src, 0x6040);
            if (dataSize != PAYLOAD_SIZE)
                return "FAIL:payload_size";

            byte[] head = new byte[0x2048];
            Buffer.BlockCopy(src, 0x4000, head, 0, 0x2044);
            uint expectedHead = U32(src, 0x6044);
            uint gotHead = Crc32(head);
            if (expectedHead != gotHead)
                return "FAIL:header_crc";

            int payloadEnd = HEADER + PAYLOAD_SIZE;
            if (payloadEnd > src.Length)
                return "FAIL:payload_bounds";

            for (int i = payloadEnd; i < src.Length; i++)
                if (src[i] != 0)
                    return "FAIL:padding";

            byte[] enc = new byte[PAYLOAD_SIZE];
            Buffer.BlockCopy(src, HEADER, enc, 0, PAYLOAD_SIZE);

            uint seed = U32(enc, SEED_OFF);
            byte[] encPrefix = new byte[SEED_OFF];
            Buffer.BlockCopy(enc, 0, encPrefix, 0, SEED_OFF);
            byte[] pre = new PsoV2(seed).CryptLE(encPrefix);

            byte[] dec = new byte[PAYLOAD_SIZE];
            Buffer.BlockCopy(pre, 0, dec, 0, pre.Length);
            Buffer.BlockCopy(enc, SEED_OFF, dec, SEED_OFF, PAYLOAD_SIZE - SEED_OFF);

            uint expectedPayload = U32(dec, 0);
            byte[] check = (byte[])dec.Clone();
            check[0] = check[1] = check[2] = check[3] = 0;
            uint gotPayload = Crc32(check);
            if (expectedPayload != gotPayload)
                return "FAIL:payload_crc";

            uint signature = U32(dec, CHAR + 0x424);
            if (signature != SIG)
                return "FAIL:character_signature";

            int numItems = dec[CHAR];
            int language = dec[CHAR + 3];
            int disp = CHAR + 0x34C;
            uint levelIndex = U32(dec, disp + 0x18);
            int visual = disp + 0x24;
            int sh = visual + 0x10;
            int sectionId = dec[sh + 0x20];
            int classId = dec[sh + 0x21];

            if (numItems > 30 || language >= 8 || levelIndex > 199 ||
                sectionId >= 10 || classId >= 12)
                return "FAIL:structure";

            return "PASS:seed=0x" + seed.ToString("X8") +
                   ";header_crc=0x" + expectedHead.ToString("X8") +
                   ";payload_crc=0x" + expectedPayload.ToString("X8") +
                   ";signature=0x" + signature.ToString("X8");
        }
        catch (Exception ex)
        {
            return "FAIL:exception:" + ex.GetType().Name + ":" + ex.Message;
        }
    }
}
"@

$script:RawHandle = $null
$script:ImageStream = $null
$script:SourceLength = 0L
$script:SourceLabel = $null
$script:RawSectorSize = 512

function Open-Source([string]$RawPath, [string]$FilePath, [long]$KnownSize = 0) {
    if ($FilePath) {
        $resolved = (Resolve-Path $FilePath).Path
        $script:ImageStream = [IO.File]::Open(
            $resolved,
            [IO.FileMode]::Open,
            [IO.FileAccess]::Read,
            [IO.FileShare]::Read)
        $script:SourceLength = $script:ImageStream.Length
        $script:SourceLabel = $resolved
        return
    }

    $script:RawHandle = [RagolRawDisk]::OpenReadOnly($RawPath)
    $script:RawSectorSize = [RagolRawDisk]::GetBytesPerSector($script:RawHandle)
    if ($KnownSize -gt 0) {
        $script:SourceLength = $KnownSize
    } else {
        $script:SourceLength = [RagolRawDisk]::GetLength($script:RawHandle)
    }
    $script:SourceLabel = $RawPath
    Write-Status ("Raw device sector size: {0} bytes" -f $script:RawSectorSize)
}

function Close-Source {
    if ($script:RawHandle) {
        $script:RawHandle.Dispose()
        $script:RawHandle = $null
        $script:RawSectorSize = 512
    }
    if ($script:ImageStream) {
        $script:ImageStream.Dispose()
        $script:ImageStream = $null
    }
}

function Read-At([long]$Offset, [int]$Count) {
    if ($Offset -lt 0 -or $Count -lt 0 -or ($Offset + $Count) -gt $script:SourceLength) {
        throw "Read outside source bounds: offset=$Offset count=$Count length=$script:SourceLength"
    }

    if ($script:ImageStream) {
        [void]$script:ImageStream.Seek($Offset, [IO.SeekOrigin]::Begin)
        $buf = New-Object byte[] $Count
        $done = 0
        while ($done -lt $Count) {
            $n = $script:ImageStream.Read($buf, $done, $Count - $done)
            if ($n -le 0) { break }
            $done += $n
        }
        if ($done -ne $Count) {
            if ($done -eq 0) { return [byte[]]@() }
            $small = New-Object byte[] $done
            [Array]::Copy($buf, 0, $small, 0, $done)
            return $small
        }
        return $buf
    }

    return [RagolRawDisk]::ReadAtAligned($script:RawHandle, $Offset, $Count, $script:RawSectorSize)
}

function U16([byte[]]$b, [int]$o) {
    return [BitConverter]::ToUInt16($b, $o)
}
function U32([byte[]]$b, [int]$o) {
    return [BitConverter]::ToUInt32($b, $o)
}
function Round-Up4096([long]$n) {
    return [long](([Math]::Floor(($n + 4095) / 4096)) * 4096)
}

function New-FatxLayout([long]$PartitionOffset, [long]$PartitionSize, [int]$SectorSize, [uint32]$SectorsPerCluster, [uint32]$RootCluster) {
    $allowedSpc = @(1,2,4,8,16,32,64,128,256,512,1024)
    if ($allowedSpc -notcontains [int]$SectorsPerCluster) { return $null }
    if ($SectorSize -ne 512 -and $SectorSize -ne 4096) { return $null }

    $alignedSize = $PartitionSize - ($PartitionSize % $SectorSize)
    if ($alignedSize -lt 8192) { return $null }

    $bytesPerCluster = [long]$SectorsPerCluster * $SectorSize
    if ($bytesPerCluster -le 0) { return $null }

    $fatEntries = [long][Math]::Floor($alignedSize / $bytesPerCluster) + 1
    $fatType = if ($fatEntries -lt 0xfff0) { 16 } else { 32 }
    $entrySize = if ($fatType -eq 16) { 2 } else { 4 }
    $fatSize = Round-Up4096 ($fatEntries * $entrySize)
    $clusterOffset = $PartitionOffset + 4096 + $fatSize
    $numClusters = [long][Math]::Floor(($alignedSize - $fatSize - 4096) / $bytesPerCluster) + 1

    if ($RootCluster -lt 1 -or $RootCluster -ge ($numClusters + 1)) { return $null }
    if ($clusterOffset -ge ($PartitionOffset + $alignedSize)) { return $null }

    return [pscustomobject]@{
        PartitionOffset = $PartitionOffset
        PartitionSize = $alignedSize
        SectorSize = $SectorSize
        SectorsPerCluster = [int]$SectorsPerCluster
        BytesPerCluster = $bytesPerCluster
        RootCluster = [long]$RootCluster
        FatOffset = $PartitionOffset + 4096
        FatType = $fatType
        FatEntrySize = $entrySize
        FatSize = $fatSize
        ClusterOffset = $clusterOffset
        NumClusters = $numClusters
    }
}


function New-FatxLayoutExplicit(
    [long]$PartitionOffset,
    [long]$PartitionSize,
    [int]$RawSectorSize,
    [long]$BytesPerCluster,
    [uint32]$RootCluster,
    [int]$FatEntrySize,
    [string]$GeometryLabel
) {
    if ($RawSectorSize -ne 512 -and $RawSectorSize -ne 4096) { return $null }
    if ($BytesPerCluster -lt 512 -or ($BytesPerCluster % 512) -ne 0) { return $null }
    if ($FatEntrySize -ne 2 -and $FatEntrySize -ne 4) { return $null }

    $alignedSize = $PartitionSize - ($PartitionSize % $RawSectorSize)
    if ($alignedSize -lt 8192) { return $null }

    $fatEntries = [long][Math]::Floor($alignedSize / $BytesPerCluster) + 1
    $fatSize = Round-Up4096 ($fatEntries * $FatEntrySize)
    $clusterOffset = $PartitionOffset + 4096 + $fatSize
    $numClusters = [long][Math]::Floor(($alignedSize - $fatSize - 4096) / $BytesPerCluster) + 1

    if ($RootCluster -lt 1 -or $RootCluster -ge ($numClusters + 1)) { return $null }
    if ($clusterOffset -ge ($PartitionOffset + $alignedSize)) { return $null }

    return [pscustomobject]@{
        PartitionOffset = $PartitionOffset
        PartitionSize = $alignedSize
        SectorSize = $RawSectorSize
        SectorsPerCluster = [int]($BytesPerCluster / $RawSectorSize)
        BytesPerCluster = [long]$BytesPerCluster
        RootCluster = [long]$RootCluster
        FatOffset = $PartitionOffset + 4096
        FatType = if ($FatEntrySize -eq 2) { 16 } else { 32 }
        FatEntrySize = $FatEntrySize
        FatSize = [long]$fatSize
        ClusterOffset = [long]$clusterOffset
        NumClusters = [long]$numClusters
        GeometryLabel = $GeometryLabel
    }
}


function Get-FatWindow($fs, [long]$CenterCluster, [int]$Radius = 4) {
    $start = [Math]::Max(1, $CenterCluster - $Radius)
    $end = $CenterCluster + $Radius
    $lines = @()

    for ($c = $start; $c -le $end; $c++) {
        $base = [long]$fs.FatOffset
        try {
            $b4 = Read-At ($base + ($c * 4)) 4
            $v32 = U32 $b4 0
            $b2 = Read-At ($base + ($c * 2)) 2
            $v16 = U16 $b2 0
            $lines += ("cluster {0}: FAT32@+{1}=0x{2:X8} | FAT16@+{3}=0x{4:X4}" -f
                $c, ($c*4), $v32, ($c*2), $v16)
        } catch {
            $lines += ("cluster {0}: ERR {1}" -f $c, $_.Exception.Message)
        }
    }
    return $lines
}

function Get-FatChainPreview($fs, [long]$StartCluster, [int]$Max = 12) {
    $items = @()
    $cluster = $StartCluster
    $seen = New-Object 'System.Collections.Generic.HashSet[long]'
    for ($i = 0; $i -lt $Max -and $cluster -ge 1; $i++) {
        if (-not $seen.Add($cluster)) {
            $items += ("{0}->LOOP" -f $cluster)
            break
        }

        try {
            $entry = Get-FatEntry $fs $cluster
            if ($fs.FatType -eq 16) {
                $items += ("{0}->0x{1:X4}" -f $cluster, $entry)
            } else {
                $items += ("{0}->0x{1:X8}" -f $cluster, $entry)
            }

            if (Test-FatEntryIsTerminal $fs ([uint64]$entry)) { break }
            $cluster = [long]$entry
        } catch {
            $items += ("{0}->ERR" -f $cluster)
            break
        }
    }
    return ($items -join " | ")
}

function Get-ClusterOffset($fs, [long]$Cluster) {
    if ($Cluster -lt 1 -or $Cluster -ge ($fs.NumClusters + 1)) {
        throw "FATX cluster out of range: $Cluster"
    }
    return [long]$fs.ClusterOffset + (($Cluster - 1) * [long]$fs.BytesPerCluster)
}

function Get-FatEntry($fs, [long]$Cluster) {
    $off = [long]$fs.FatOffset + ($Cluster * $fs.FatEntrySize)
    $b = Read-At $off $fs.FatEntrySize
    if ($b.Length -ne $fs.FatEntrySize) { throw "Could not read FAT entry $Cluster" }
    if ($fs.FatType -eq 16) { return [uint32](U16 $b 0) }
    return [uint32](U32 $b 0)
}

function Test-FatEntryIsTerminal($fs, [uint64]$Entry) {
    if ($Entry -eq 0) { return $true }

    if ($fs.FatType -eq 16) {
        return ($Entry -ge $script:Fat16ReservedStart)
    }

    return ($Entry -ge $script:Fat32ReservedStart)
}

function Get-NextCluster($fs, [long]$Cluster) {
    $e = [uint64](Get-FatEntry $fs $Cluster)

    if (Test-FatEntryIsTerminal $fs $e) {
        return $null
    }

    # Only ordinary data-cluster values reach here.
    return [long]$e
}

function Get-DirectoryEntries($fs, [long]$StartCluster) {
    $entries = @()
    $cluster = $StartCluster
    $seen = New-Object 'System.Collections.Generic.HashSet[long]'

    while ($cluster) {
        if (-not $seen.Add($cluster)) { throw "FATX directory cluster loop detected" }
        $base = Get-ClusterOffset $fs $cluster
        $count = [int]($fs.BytesPerCluster / 64)

        for ($i = 0; $i -lt $count; $i++) {
            $raw = Read-At ($base + ($i * 64)) 64
            if ($raw.Length -ne 64) { throw "Short FATX directory read" }

            $nameLen = [int]$raw[0]
            if ($nameLen -eq 0xff -or $nameLen -eq 0x00) {
                return $entries
            }
            if ($nameLen -eq 0xe5) { continue }
            if ($nameLen -lt 1 -or $nameLen -gt 42) {
                throw "Invalid FATX filename length $nameLen"
            }

            $name = [Text.Encoding]::ASCII.GetString($raw, 2, $nameLen)
            $attr = [int]$raw[1]
            $firstCluster = [long](U32 $raw 44)
            $fileSize = [long](U32 $raw 48)

            $entries += [pscustomobject]@{
                Name = $name
                Attributes = $attr
                IsDirectory = (($attr -band 0x10) -ne 0)
                FirstCluster = $firstCluster
                FileSize = $fileSize
            }
        }

        $cluster = Get-NextCluster $fs $cluster
    }

    return $entries
}

function Find-DirectoryEntry($fs, [long]$DirectoryCluster, [string]$Name) {
    foreach ($entry in (Get-DirectoryEntries $fs $DirectoryCluster)) {
        if ($entry.Name.Equals($Name, [StringComparison]::OrdinalIgnoreCase)) {
            return $entry
        }
    }
    return $null
}

function Find-FileRecursive($fs, [long]$DirectoryCluster, [string]$Target, [string]$Prefix, [int]$Depth, $Visited) {
    if ($Depth -lt 0) { return $null }
    if (-not $Visited.Add($DirectoryCluster)) { return $null }

    foreach ($entry in (Get-DirectoryEntries $fs $DirectoryCluster)) {
        $path = if ($Prefix) { "$Prefix/$($entry.Name)" } else { "/$($entry.Name)" }

        if (-not $entry.IsDirectory -and $entry.Name.Equals($Target, [StringComparison]::OrdinalIgnoreCase)) {
            return [pscustomobject]@{
                Path = $path
                Entry = $entry
            }
        }

        if ($entry.IsDirectory -and $entry.FirstCluster -gt 0 -and $Depth -gt 0) {
            $found = Find-FileRecursive $fs $entry.FirstCluster $Target $path ($Depth - 1) $Visited
            if ($found) { return $found }
        }
    }
    return $null
}

function Read-FatxFile($fs, $entry) {
    if ($entry.FileSize -lt 0 -or $entry.FileSize -gt 134217728) {
        throw "Refusing unreasonable FATX file size: $($entry.FileSize)"
    }

    $out = New-Object byte[] ([int]$entry.FileSize)
    $written = 0
    $cluster = [long]$entry.FirstCluster
    $seen = New-Object 'System.Collections.Generic.HashSet[long]'

    while ($written -lt $entry.FileSize) {
        if ($cluster -lt 1) { throw "FATX file chain ended early" }
        if (-not $seen.Add($cluster)) { throw "FATX file cluster loop detected" }

        $remaining = [long]$entry.FileSize - $written
        $take = [int][Math]::Min([long]$fs.BytesPerCluster, $remaining)
        $chunk = Read-At (Get-ClusterOffset $fs $cluster) $take
        if ($chunk.Length -ne $take) { throw "Short FATX file cluster read" }

        [Array]::Copy($chunk, 0, $out, $written, $take)
        $written += $take
        if ($written -lt $entry.FileSize) {
            $cluster = Get-NextCluster $fs $cluster
            if ($null -eq $cluster) { throw "FATX file chain ended before file size" }
        }
    }
    return $out
}

function Get-FatxCandidatesAtOffset([long]$Offset) {
    $candidates = @()
    if (($Offset + 4096) -gt $script:SourceLength) { return $candidates }

    $sb = Read-At $Offset 16
    if ($sb.Length -lt 16) { return $candidates }

    for ($i=0; $i -lt 4; $i++) {
        if ($sb[$i] -ne $FatxSignature[$i]) { return $candidates }
    }

    $reportedSpc = [long](U32 $sb 8)
    $root = U32 $sb 12
    if ($reportedSpc -lt 1 -or $reportedSpc -gt 1024) { return $candidates }

    $partitionSize = $script:SourceLength - $Offset
    $reportedCluster = $reportedSpc * 512L

    # Xbox Memory Units can have a "reported" geometry that differs from
    # physical data alignment. XBMUT documents an 8x MU factor. Large USB
    # Memory Units also exist, so we probe a short conservative set and
    # validate against the actual PSO directory + file chain.
    $factors = @(8, 16, 4, 2, 1, 32)

    foreach ($factor in $factors) {
        $realCluster = $reportedCluster * $factor
        if ($realCluster -lt 2048 -or $realCluster -gt 262144) { continue }

        $estimatedEntries = [long][Math]::Floor($partitionSize / $realCluster) + 1
        $genericEntrySize = if ($estimatedEntries -lt 0xFFF0) { 2 } else { 4 }

        $entrySizes = @($genericEntrySize)
        if ($genericEntrySize -eq 4) {
            # MU-specific FAT16 fallback from XBMUT. It is only accepted if
            # the PSO hierarchy and full PSO_CHARACTER chain validate.
            $entrySizes += 2
        }

        foreach ($entrySize in ($entrySizes | Select-Object -Unique)) {
            $label = "MU factor ${factor}x / cluster $realCluster / FAT$($entrySize*8)"
            $fs = New-FatxLayoutExplicit $Offset $partitionSize $script:RawSectorSize $realCluster $root $entrySize $label
            if (-not $fs) { continue }

            try {
                $title = Find-DirectoryEntry $fs $fs.RootCluster $TitleId
                if (-not ($title -and $title.IsDirectory)) { continue }

                $fs | Add-Member -NotePropertyName TitleEntry -NotePropertyValue $title
                $candidates += $fs
            } catch {
                if ($VerboseScan) {
                    Write-Host ("  Candidate rejected: {0}: {1}" -f $label, $_.Exception.Message)
                }
            }
        }
    }

    return $candidates
}

function Find-FatxFilesystemAndPso {
    $offsets = New-Object 'System.Collections.Generic.List[long]'
    [void]$offsets.Add(0L)

    # Conservative fallback: look for FATX superblocks in the first 16 MiB.
    $limit = [Math]::Min([long](16MB), $script:SourceLength - 4096)
    for ($off = 4096L; $off -le $limit; $off += 4096L) {
        $sig = Read-At $off 4
        if ($sig.Length -eq 4 -and
            $sig[0] -eq $FatxSignature[0] -and
            $sig[1] -eq $FatxSignature[1] -and
            $sig[2] -eq $FatxSignature[2] -and
            $sig[3] -eq $FatxSignature[3]) {
            if (-not $offsets.Contains($off)) { [void]$offsets.Add($off) }
        }
    }

    $diagnostics = @()

    foreach ($off in $offsets) {
        foreach ($fs in @(Get-FatxCandidatesAtOffset $off)) {
            try {
                $visited = New-Object 'System.Collections.Generic.HashSet[long]'
                $found = Find-FileRecursive $fs $fs.TitleEntry.FirstCluster $TargetFile "/$TitleId" 4 $visited
                if (-not $found) {
                    $diagnostics += ("{0}: title found, PSO_CHARACTER not found" -f $fs.GeometryLabel)
                    continue
                }

                $preview = Get-FatChainPreview $fs $found.Entry.FirstCluster 12
                Write-Host ("  Candidate: {0}" -f $fs.GeometryLabel) -ForegroundColor DarkCyan
                Write-Host ("    FAT size: {0} bytes · data offset: 0x{1:X} · first cluster: {2} · file size: {3}" -f
                    $fs.FatSize, $fs.ClusterOffset, $found.Entry.FirstCluster, $found.Entry.FileSize) -ForegroundColor DarkCyan
                Write-Host ("    Chain: {0}" -f $preview) -ForegroundColor DarkCyan

                if ($found.Entry.FileSize -ne $ExpectedCharacterSize) {
                    $diagnostics += ("{0}: unexpected PSO_CHARACTER size {1}" -f $fs.GeometryLabel, $found.Entry.FileSize)
                    continue
                }

                $bytes = $null
                $recoveryMode = "fat-chain"

                try {
                    $bytes = Read-FatxFile $fs $found.Entry
                } catch {
                    $chainError = $_.Exception.Message
                    $diagnostics += ("{0}: {1}" -f $fs.GeometryLabel, $chainError)

                    Write-Host "    FAT window around file start:" -ForegroundColor DarkYellow
                    foreach ($line in (Get-FatWindow $fs $found.Entry.FirstCluster 6)) {
                        Write-Host ("      {0}" -f $line) -ForegroundColor DarkYellow
                    }

                    # PSO-specific read-only recovery:
                    # If the directory entry is correct but the MU FAT chain is represented
                    # differently, try the physical contiguous extent beginning at the
                    # known first cluster. Accept it ONLY if PSO's own crypto/checksum/
                    # signature validations all pass.
                    try {
                        $startOffset = Get-ClusterOffset $fs $found.Entry.FirstCluster
                        if (($startOffset + $ExpectedCharacterSize) -le
                            ($fs.PartitionOffset + $fs.PartitionSize)) {
                            $contig = Read-At $startOffset $ExpectedCharacterSize
                            $validation = [RagolPsoValidator]::Validate($contig)
                            $contigHash = [RagolPsoValidator]::Sha256($contig)
                            Write-Host ("    Contiguous 64 KiB probe: {0}" -f $validation) -ForegroundColor DarkMagenta
                            Write-Host ("    Contiguous SHA256: {0}" -f $contigHash) -ForegroundColor DarkMagenta

                            if ($validation.StartsWith("PASS:")) {
                                $bytes = $contig
                                $recoveryMode = "contiguous-extent-psoc-validated"
                                Write-Host "    PSO validation accepted the contiguous extent." -ForegroundColor Green
                            }
                        }
                    } catch {
                        $diagnostics += ("{0}: contiguous PSO probe failed: {1}" -f
                            $fs.GeometryLabel, $_.Exception.Message)
                    }
                }

                if ($null -eq $bytes -or $bytes.Length -ne $ExpectedCharacterSize) {
                    continue
                }

                $psoValidation = [RagolPsoValidator]::Validate($bytes)
                if (-not $psoValidation.StartsWith("PASS:")) {
                    $diagnostics += ("{0}: full bytes rejected by PSO validator: {1}" -f
                        $fs.GeometryLabel, $psoValidation)
                    continue
                }

                Write-Host ("    PSO validator: {0}" -f $psoValidation) -ForegroundColor Green

                return [pscustomobject]@{
                    Fs = $fs
                    Found = $found
                    Bytes = $bytes
                    ChainPreview = $preview
                    Diagnostics = $diagnostics
                    RecoveryMode = $recoveryMode
                    PsoValidation = $psoValidation
                }
            } catch {
                $diagnostics += ("{0}: {1}" -f $fs.GeometryLabel, $_.Exception.Message)
                if ($VerboseScan) {
                    Write-Host ("    Candidate failed: {0}" -f $_.Exception.Message) -ForegroundColor DarkGray
                }
            }
        }
    }

    if ($diagnostics.Count -gt 0) {
        Write-Host ""
        Write-Host "FATX candidate diagnostics:" -ForegroundColor Yellow
        foreach ($d in $diagnostics) {
            Write-Host ("  - {0}" -f $d) -ForegroundColor DarkYellow
        }
    }

    return $null
}

function Get-UsbCandidates {
    $out = @()
    try {
        foreach ($d in (Get-Disk | Where-Object { $_.BusType -eq "USB" })) {
            $out += [pscustomobject]@{
                Path = "\\.\PhysicalDrive$($d.Number)"
                Size = [long]$d.Size
                Model = [string]$d.FriendlyName
                Number = [int]$d.Number
            }
        }
    } catch {
        # Fallback for older Windows/Storage module situations.
        foreach ($d in (Get-CimInstance Win32_DiskDrive | Where-Object {
            $_.PNPDeviceID -like "USBSTOR*" -or $_.InterfaceType -eq "USB"
        })) {
            $out += [pscustomobject]@{
                Path = "\\.\PhysicalDrive$($d.Index)"
                Size = [long]$d.Size
                Model = [string]$d.Model
                Number = [int]$d.Index
            }
        }
    }
    return $out | Sort-Object Number -Unique
}


function New-RagolBridgeToken {
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $b = New-Object byte[] 24
        $rng.GetBytes($b)
        return (($b | ForEach-Object { $_.ToString("x2") }) -join "")
    } finally {
        $rng.Dispose()
    }
}

function Get-RagolQueryValue([string]$Target, [string]$Name) {
    $qIndex = $Target.IndexOf("?")
    if ($qIndex -lt 0) { return $null }
    $query = $Target.Substring($qIndex + 1)
    foreach ($part in $query.Split("&")) {
        if ([string]::IsNullOrWhiteSpace($part)) { continue }
        $kv = $part.Split("=", 2)
        $k = [Uri]::UnescapeDataString($kv[0])
        if ($k -eq $Name) {
            if ($kv.Length -lt 2) { return "" }
            return [Uri]::UnescapeDataString($kv[1])
        }
    }
    return $null
}

function Send-RagolHttpResponse(
    [IO.Stream]$Stream,
    [int]$Status,
    [string]$Reason,
    [hashtable]$Headers,
    [byte[]]$Body
) {
    if ($null -eq $Body) { $Body = [byte[]]@() }

    $all = [ordered]@{
        "Connection" = "close"
        "Cache-Control" = "no-store, no-cache, must-revalidate"
        "Pragma" = "no-cache"
        "X-Content-Type-Options" = "nosniff"
        "Content-Length" = [string]$Body.Length
    }
    foreach ($k in $Headers.Keys) { $all[$k] = [string]$Headers[$k] }

    $head = "HTTP/1.1 $Status $Reason`r`n"
    foreach ($k in $all.Keys) {
        $head += "$k`: $($all[$k])`r`n"
    }
    $head += "`r`n"

    $headBytes = [Text.Encoding]::ASCII.GetBytes($head)
    $Stream.Write($headBytes, 0, $headBytes.Length)
    if ($Body.Length -gt 0) {
        $Stream.Write($Body, 0, $Body.Length)
    }
    $Stream.Flush()
}

function Get-RagolCorsHeaders([string]$Origin) {
    $h = @{
        "Access-Control-Allow-Methods" = "GET, OPTIONS"
        "Access-Control-Allow-Headers" = "Content-Type"
        "Access-Control-Allow-Private-Network" = "true"
        "Access-Control-Max-Age" = "600"
        "Vary" = "Origin, Access-Control-Request-Private-Network"
    }
    if ($Origin -eq "https://jrpg.world" -or $Origin -eq "https://www.jrpg.world") {
        $h["Access-Control-Allow-Origin"] = $Origin
    }
    return $h
}

function Test-RagolOriginAllowed([string]$Origin) {
    if ([string]::IsNullOrWhiteSpace($Origin)) { return $true } # local manual diagnostics
    return ($Origin -eq "https://jrpg.world" -or $Origin -eq "https://www.jrpg.world")
}

function Start-RagolLocalBridge(
    [byte[]]$SaveBytes,
    $Meta,
    [int]$TimeoutSeconds = 480
) {
    if ($null -eq $SaveBytes -or $SaveBytes.Length -ne 65536) {
        throw "Ragol Link bridge refuses a save that is not exactly 65,536 bytes."
    }

    $validation = [RagolPsoValidator]::Validate($SaveBytes)
    if (-not $validation.StartsWith("PASS:")) {
        throw "Ragol Link bridge refuses an unvalidated PSO save: $validation"
    }

    $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0)
    $listener.Start()
    $port = ([Net.IPEndPoint]$listener.LocalEndpoint).Port
    $token = New-RagolBridgeToken
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    $consumed = $false
    $servedSave = $false

    $launchUrl = "https://jrpg.world/pso/?ragol=1#port=$port&token=$token"

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " RAGOL LINK LOCALHOST BRIDGE READY" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "Listen: 127.0.0.1:$port"
    Write-Host "Origin: https://jrpg.world only"
    Write-Host ("Expires: {0} seconds" -f $TimeoutSeconds)
    Write-Host "Raw save remains on this PC. Nothing is uploaded by the bridge." -ForegroundColor Green
    Write-Host ""
    Write-Host "Opening JRPG.WORLD /pso/ ..."
    Write-Host "Chrome may ask whether jrpg.world may access the local device/network."
    Write-Host "Choose Allow. This is the localhost bridge on your own PC." -ForegroundColor Yellow

    Start-Process $launchUrl

    try {
        while (-not $consumed -and [DateTime]::UtcNow -lt $deadline) {
            if (-not $listener.Pending()) {
                Start-Sleep -Milliseconds 60
                continue
            }

            $client = $listener.AcceptTcpClient()
            try {
                $client.ReceiveTimeout = 5000
                $client.SendTimeout = 5000
                $stream = $client.GetStream()
                $reader = New-Object IO.StreamReader(
                    $stream,
                    [Text.Encoding]::ASCII,
                    $false,
                    8192,
                    $true
                )

                $requestLine = $reader.ReadLine()
                if ([string]::IsNullOrWhiteSpace($requestLine)) {
                    $client.Close()
                    continue
                }

                $headers = @{}
                while ($true) {
                    $line = $reader.ReadLine()
                    if ($null -eq $line -or $line -eq "") { break }
                    $colon = $line.IndexOf(":")
                    if ($colon -gt 0) {
                        $name = $line.Substring(0, $colon).Trim().ToLowerInvariant()
                        $value = $line.Substring($colon + 1).Trim()
                        $headers[$name] = $value
                    }
                }

                $parts = $requestLine.Split(" ")
                if ($parts.Length -lt 2) {
                    Send-RagolHttpResponse $stream 400 "Bad Request" @{"Content-Type"="text/plain; charset=utf-8"} ([Text.Encoding]::UTF8.GetBytes("bad request"))
                    continue
                }

                $method = $parts[0].ToUpperInvariant()
                $target = $parts[1]
                $path = $target.Split("?", 2)[0]
                $origin = if ($headers.ContainsKey("origin")) { [string]$headers["origin"] } else { "" }
                $cors = Get-RagolCorsHeaders $origin

                if (-not (Test-RagolOriginAllowed $origin)) {
                    Send-RagolHttpResponse $stream 403 "Forbidden" $cors ([Text.Encoding]::UTF8.GetBytes("origin not allowed"))
                    continue
                }

                if ($method -eq "OPTIONS") {
                    Send-RagolHttpResponse $stream 204 "No Content" $cors ([byte[]]@())
                    continue
                }

                if ($method -ne "GET") {
                    Send-RagolHttpResponse $stream 405 "Method Not Allowed" $cors ([Text.Encoding]::UTF8.GetBytes("GET only"))
                    continue
                }

                $requestToken = Get-RagolQueryValue $target "token"
                if ([string]::IsNullOrWhiteSpace($requestToken) -or $requestToken -ne $token) {
                    Send-RagolHttpResponse $stream 403 "Forbidden" $cors ([Text.Encoding]::UTF8.GetBytes("bad token"))
                    continue
                }

                if ($path -eq "/v1/status") {
                    $status = [ordered]@{
                        ready = $true
                        version = "alpha2"
                        platform = "original-xbox"
                        size = $SaveBytes.Length
                        sha256 = [string]$Meta.sha256
                        extraction_mode = [string]$Meta.extraction_mode
                        fatx_path = [string]$Meta.fatx_path
                        expires_seconds = [Math]::Max(0, [int]($deadline - [DateTime]::UtcNow).TotalSeconds)
                    }
                    $body = [Text.Encoding]::UTF8.GetBytes(($status | ConvertTo-Json -Compress))
                    $h = @{}
                    foreach ($k in $cors.Keys) { $h[$k] = $cors[$k] }
                    $h["Content-Type"] = "application/json; charset=utf-8"
                    Send-RagolHttpResponse $stream 200 "OK" $h $body
                    Write-Host "[BRIDGE] jrpg.world connected." -ForegroundColor DarkCyan
                    continue
                }

                if ($path -eq "/v1/save") {
                    $h = @{}
                    foreach ($k in $cors.Keys) { $h[$k] = $cors[$k] }
                    $h["Content-Type"] = "application/octet-stream"
                    $h["Content-Disposition"] = 'attachment; filename="PSO_CHARACTER"'
                    $h["X-Ragol-SHA256"] = [string]$Meta.sha256
                    $h["Access-Control-Expose-Headers"] = "X-Ragol-SHA256"
                    Send-RagolHttpResponse $stream 200 "OK" $h $SaveBytes
                    $servedSave = $true
                    Write-Host "[BRIDGE] PSO_CHARACTER handed to the local browser." -ForegroundColor Green
                    continue
                }

                if ($path -eq "/v1/done") {
                    $body = [Text.Encoding]::UTF8.GetBytes('{"ok":true}')
                    $h = @{}
                    foreach ($k in $cors.Keys) { $h[$k] = $cors[$k] }
                    $h["Content-Type"] = "application/json; charset=utf-8"
                    Send-RagolHttpResponse $stream 200 "OK" $h $body
                    if ($servedSave) {
                        $consumed = $true
                        Write-Host "[BRIDGE] Browser confirmed the verified save is linked. Closing localhost bridge." -ForegroundColor Green
                    }
                    continue
                }

                Send-RagolHttpResponse $stream 404 "Not Found" $cors ([Text.Encoding]::UTF8.GetBytes("not found"))
            }
            catch {
                Write-Host ("[BRIDGE] Request error: {0}" -f $_.Exception.Message) -ForegroundColor DarkYellow
            }
            finally {
                try { $client.Close() } catch {}
            }
        }
    }
    finally {
        try { $listener.Stop() } catch {}
    }

    if ($consumed) {
        return [pscustomobject]@{
            Success = $true
            Port = $port
            ServedSave = $servedSave
            Reason = "browser-confirmed"
        }
    }

    Write-Host ""
    Write-Host "[BRIDGE] Timed out before the browser confirmed linking." -ForegroundColor Yellow
    Write-Host "The extracted output/PSO_CHARACTER still exists as a manual fallback." -ForegroundColor Yellow
    return [pscustomobject]@{
        Success = $false
        Port = $port
        ServedSave = $servedSave
        Reason = "timeout"
    }
}

function Extract-FromCurrentSource([string]$Model = "") {
    Write-Status "Scanning $script:SourceLabel read-only..."
    $probe = Find-FatxFilesystemAndPso
    if (-not $probe) {
        throw "No FATX geometry produced a complete validated /$TitleId/.../$TargetFile chain."
    }

    $fs = $probe.Fs
    $found = $probe.Found
    $bytes = $probe.Bytes

    Write-Status ("FATX/PSO geometry selected: {0}" -f $fs.GeometryLabel)
    Write-Status ("Cluster {0} bytes · FAT{1} · data offset 0x{2:X} · root cluster {3}" -f
        $fs.BytesPerCluster, $fs.FatType, $fs.ClusterOffset, $fs.RootCluster)

    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    $outPath = Join-Path $OutputDirectory $TargetFile
    [IO.File]::WriteAllBytes($outPath, $bytes)

    $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $outPath).Hash.ToLowerInvariant()
    $meta = [ordered]@{
        format = "JRPG.WORLD Ragol Link Direct Xbox USB Alpha 2"
        read_only = $true
        source = $script:SourceLabel
        model = $Model
        source_size = $script:SourceLength
        fatx_partition_offset = $fs.PartitionOffset
        fatx_sector_size = $fs.SectorSize
        fatx_sectors_per_cluster = $fs.SectorsPerCluster
        fatx_bytes_per_cluster = $fs.BytesPerCluster
        fatx_fat_type = $fs.FatType
        fatx_fat_size = $fs.FatSize
        fatx_data_offset = $fs.ClusterOffset
        fatx_geometry = $fs.GeometryLabel
        fatx_chain_preview = $probe.ChainPreview
        extraction_mode = $probe.RecoveryMode
        pso_validation = $probe.PsoValidation
        xbox_title_id = $TitleId
        fatx_path = $found.Path
        extracted_file = $outPath
        extracted_size = $bytes.Length
        sha256 = $hash
        utc = [DateTime]::UtcNow.ToString("o")
    }

    $jsonPath = Join-Path $OutputDirectory "RAGOL_LINK_SCAN.json"
    ($meta | ConvertTo-Json -Depth 5) | Set-Content -LiteralPath $jsonPath -Encoding UTF8

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host " ORIGINAL XBOX PSO SAVE FOUND" -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host "Path:   $($found.Path)"
    Write-Host "Size:   $($bytes.Length) bytes"
    Write-Host ("Mode:   {0}" -f $probe.RecoveryMode)
    Write-Host ("Chain:  {0}" -f $probe.ChainPreview)
    Write-Host "SHA256: $hash"
    Write-Host "PSO validation: PASS" -ForegroundColor Green
    Write-Host "Output: $outPath"
    Write-Host ""
    Write-Host "The Xbox USB was opened GENERIC_READ only. Nothing was mounted or written." -ForegroundColor Cyan

    try { Set-Clipboard -Value $outPath } catch {}

    if (-not $NoLaunch) {
        try {
            $bridge = Start-RagolLocalBridge $bytes $meta
            $meta["bridge"] = [ordered]@{
                version = "alpha2"
                success = [bool]$bridge.Success
                served_save = [bool]$bridge.ServedSave
                reason = [string]$bridge.Reason
            }
            ($meta | ConvertTo-Json -Depth 7) | Set-Content -LiteralPath $jsonPath -Encoding UTF8

            if (-not $bridge.Success) {
                Write-Host ""
                Write-Host "Manual fallback:" -ForegroundColor Yellow
                Write-Host "Open https://jrpg.world/pso/ and use LINK XBOX SAVE."
                Start-Process explorer.exe -ArgumentList "/select,`"$outPath`""
            }
        }
        catch {
            Write-Host ""
            Write-Host ("Localhost bridge failed: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
            Write-Host "Falling back to the extracted PSO_CHARACTER file." -ForegroundColor Yellow
            Start-Process "https://jrpg.world/pso/"
            Start-Sleep -Milliseconds 400
            Start-Process explorer.exe -ArgumentList "/select,`"$outPath`""
        }
    }

    return $meta
}

try {
    if ($ImagePath) {
        Open-Source "" $ImagePath
        [void](Extract-FromCurrentSource "disk-image fixture")
        $global:LASTEXITCODE = 0
        return
    }

    if (-not (Test-IsAdministrator)) {
        throw "Administrator access is required for read-only raw physical-disk access. Use Run-Ragol-Link.cmd."
    }

    if ($DevicePath) {
        Open-Source $DevicePath ""
        [void](Extract-FromCurrentSource "manual device")
        $global:LASTEXITCODE = 0
        return
    }

    $candidates = @(Get-UsbCandidates)
    if ($candidates.Count -eq 0) {
        throw "No USB physical disks were detected. Plug in the Xbox-formatted USB and run again."
    }

    Write-Status ("Detected {0} USB physical disk(s)." -f $candidates.Count)
    $errors = @()

    foreach ($disk in $candidates) {
        try {
            Write-Host ""
            Write-Status ("Trying {0} · {1} · {2:N2} GiB" -f
                $disk.Path, $disk.Model, ($disk.Size / 1GB))
            Open-Source $disk.Path "" $disk.Size
            try {
                [void](Extract-FromCurrentSource $disk.Model)
        $global:LASTEXITCODE = 0
        return
            } finally {
                Close-Source
            }
        } catch {
            $errors += "$($disk.Path): $($_.Exception.Message)"
            Write-Host "  Not the PSO Xbox FATX USB: $($_.Exception.Message)" -ForegroundColor DarkGray
            Close-Source
        }
    }

    throw ("No detected USB disk contained a validated /$TitleId/.../$TargetFile save.`n" + ($errors -join "`n"))
}
catch {
    Write-Host ""
    Write-Host "RAGOL LINK could not extract a save:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "No writes were issued to any disk." -ForegroundColor Yellow
    $global:LASTEXITCODE = 1
    return
}
finally {
    Close-Source
}
