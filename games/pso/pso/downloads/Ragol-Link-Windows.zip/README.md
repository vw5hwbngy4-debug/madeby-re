# Ragol Link

**Original Xbox PSO → live save truth**

Ragol Link is a Windows companion for **Phantasy Star Online Episode I & II on the Original Xbox**.

It reads `PSO_CHARACTER` directly from an Xbox-formatted USB using read-only raw disk access, validates the save locally, and hands the verified save to the live browser session at **JRPG.WORLD / PSO** through a temporary localhost bridge.

No FATXplorer mount. No ZIP export. No file picker in the normal flow. The raw save stays on the PC.

> **First known direct Original Xbox PSO USB-to-browser save bridge.**
>
> This is a best-effort prior-art claim based on public research, not an absolute guarantee that no unpublished or obscure historical implementation ever existed.

## Quick start

1. Extract **Ragol-Link-Windows.zip**.
2. Run **`INSTALL RAGOL LINK.cmd`**.
3. Plug in the Xbox-formatted USB containing the PSO save.
4. Open **Ragol Link** from Desktop or Start.
5. Accept Windows UAC.
6. Ragol Link reads the USB, validates the character, opens `https://jrpg.world/pso/`, and links the save automatically.
7. If Chrome asks whether JRPG.WORLD may access localhost / the local network, choose **Allow**.

## What the normal flow does

```text
Original Xbox
    ↓
Xbox-formatted USB
    ↓
Windows PhysicalDrive · GENERIC_READ only
    ↓
FATX
    ↓
4d53004a/.../PSO_CHARACTER
    ↓
PSO V2 decrypt + CRC + structure validation
    ↓
temporary 127.0.0.1 bridge
    ↓
https://jrpg.world/pso/
    ↓
verified character context for Rico
```

## Privacy and safety

- Raw USB access is **read-only**.
- No FATX mount, format, repair, or filesystem write.
- `PSO_CHARACTER` is validated locally.
- Localhost bridge binds only to `127.0.0.1`.
- Random ephemeral port + one-time token.
- Browser origin restricted to JRPG.WORLD.
- Bridge closes after confirmation or timeout.
- The raw save is not uploaded to Rico by the bridge.

See **`SECURITY.txt`** for the packaged security model.

## Proven real-hardware path

M1.3 passed end-to-end on real Original Xbox save hardware:

- raw USB read: **PASS**
- logical sector size: **512 bytes**
- FATX: **FAT32**
- real data cluster: **16 KiB**
- data offset: **`0x7A000`**
- PSO chain: **`8 → 9 → 10 → 11 → EOF`**
- `PSO_CHARACTER`: **65,536 bytes**
- PSO decrypt / CRC / signature validation: **PASS**
- byte-identical parity with an independent FATXplorer export: **PASS**
- localhost bridge: **PASS**
- browser confirmation + automatic bridge shutdown: **PASS**

The private test-save fingerprint is intentionally not published.

## Requirements

- Windows 11 tested
- Windows PowerShell 5.1
- Administrator elevation for raw physical-disk access
- Original Xbox PSO Episode I & II save on an Xbox-formatted USB
- Chrome/Chromium recommended

## Scope

Current scope is deliberately narrow:

- Original Xbox
- Phantasy Star Online Episode I & II
- `PSO_CHARACTER`
- Windows companion
- JRPG.WORLD `/pso/`

GameCube and Blue Burst are not product targets in this release.

## Portable mode

If you do not want to install it, run:

`Run Ragol Link Portable.cmd`

## Diagnostics

If the normal GUI does not start, run:

`DIAGNOSTIC START.cmd`

Installed logs:

`%LOCALAPPDATA%\JRPG.WORLD\RagolLink\logs\RAGOL_LINK_LAST_RUN.log`

Startup log:

`%LOCALAPPDATA%\JRPG.WORLD\RagolLink\logs\RAGOL_LINK_STARTUP.log`

Installer log on failure:

`%TEMP%\RAGOL_LINK_INSTALL.log`

## Uninstall

Run **`UNINSTALL RAGOL LINK.cmd`** from this extracted release package.

## License and prior art

Ragol Link is licensed **GPL-3.0-or-later**.

See:

- `LICENSE`
- `THIRD_PARTY_NOTICES.txt`

## JRPG.WORLD

https://jrpg.world/pso/
