@echo off
setlocal
cd /d "%~dp0"
title JRPG.WORLD - RAGOL LINK M1.3 INSTALLER
echo JRPG.WORLD - RAGOL LINK M1.3 INSTALLER
echo.
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-RagolLink.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo Installation failed with exit code %RC%.
  echo Log: %TEMP%\RAGOL_LINK_INSTALL.log
  echo.
  pause
  exit /b %RC%
)
exit /b 0
