# Changelog

## v1.0 — 2026-08-29

- Translation queue closed to zero.
- 24,850 enabled English records compiled successfully.
- Required glyph inventory mapped completely.
- Complete English overlay built and statically validated.
- Vita3K full-merge CPK built and validated.
- Runtime boot and English dialogue confirmed.
- Game update v1.05 compatibility confirmed in runtime test.
- Initial screenshots and QA evidence packaged for public release.
