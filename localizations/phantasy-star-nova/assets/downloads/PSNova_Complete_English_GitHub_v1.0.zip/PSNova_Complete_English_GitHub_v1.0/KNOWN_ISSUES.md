# Known issues

## Vita3K: CAST player body can render black/glitched

**Observed:** On the tested Vita3K setup, a CAST player character rendered with black/glitched body materials. With **Disable Surface Sync OFF**, clothing recovered, while parts of the CAST body could remain black.

**Impact:** visual/emulator-side. NPCs, environment, UI, dialogue boxes and English text rendered normally in the same scenes.

**Workaround for capture/play:** use a non-CAST player character if affected. Trying a different Vita3K renderer/GPU configuration may also change the behavior.

Vita3K has active Phantasy Star Nova graphics/character-rendering reports, so this release does not currently classify the CAST-body artifact as a localization defect.

Related upstream issue tracker:
https://github.com/Vita3K/Vita3K/issues/4088

## Translation quality

The previously untranslated remainder was completed with machine translation / LLM assistance. Some lines may be literal or awkward even though they are functional and readable. Example categories for future polishing include natural phrasing, terminology consistency and dialogue voice.

## Full-playthrough status

Corpus completeness and runtime boot are proven; a complete manual playthrough is not yet claimed.
