# Vita3K installation

These instructions match the configuration that was runtime-tested.

## 1. Install and test the original game

Install your legitimate copy of **Phantasy Star Nova (`PCSG00351`)** in Vita3K and confirm the unmodified Japanese game boots.

## 2. Optional but recommended: game update v1.05

The English full-merge build was also tested while the official game update **v1.05** was active.

Keep the game update as Vita3K patch content under:

```text
ux0/patch/PCSG00351/
```

The v1.05 game update is separate from the Arks-Layer English partial patch used as a **build input**.

## 3. Build the English CPK

Follow [BUILD.md](BUILD.md). The output should hash to:

```text
ebf2cea4c8158f32557d52c58b111101c1818157d862cd7b1c570b096730e4ba
```

## 4. Back up the original Vita3K CPK

Close Vita3K and back up:

```text
ux0/app/PCSG00351/NOVA_FileList_Vita.cpk
```

## 5. Replace one file only

Rename:

```text
NOVA_FileList_Vita_FULL_ENGLISH.cpk
```

to:

```text
NOVA_FileList_Vita.cpk
```

and replace only:

```text
ux0/app/PCSG00351/NOVA_FileList_Vita.cpk
```

Do **not** replace the installed game's:

- `eboot.bin`
- `sce_sys`
- `sce_module`
- `disc1`
- license/work files
- package metadata

## 6. Boot

Start Phantasy Star Nova in Vita3K. English story dialogue should appear immediately in early-game scenes.

## Vita3K CAST rendering note

If a CAST player character has black/glitched body rendering, try ensuring **Disable Surface Sync is OFF**. On the tested system this restored clothing, although the CAST body could remain black. The localization text itself continued working normally.
