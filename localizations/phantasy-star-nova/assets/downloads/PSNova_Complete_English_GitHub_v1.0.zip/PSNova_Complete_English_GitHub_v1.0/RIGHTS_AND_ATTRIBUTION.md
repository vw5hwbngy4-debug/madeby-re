# Rights, provenance and attribution

## Game

**Phantasy Star Nova** is a copyrighted work of its respective rights holders, including Sega and tri-Ace. This repository does not distribute a game PKG, ROM, full original CPK, license data, `eboot.bin`, movies, textures, audio or other complete original game assets.

Users must supply their own legitimate game data.

## Arks-Layer / PSNovaTranslations

This independent completion builds on the public Arks-Layer Phantasy Star Nova English patch and translation repository:

- https://arks-layer.com/nova.php
- https://github.com/Arks-Layer/PSNovaTranslations

The existing English text and technical knowledge from that project are credited to their respective contributors. The upstream repository specifically asks contributors not to submit AI-generated translations. This project respects that boundary by remaining an **independent release**, not an upstream pull request and not an Arks-Layer-endorsed build.

## AI-assisted completion

The remaining uncovered corpus was completed using a general-purpose LLM-assisted workflow, followed by automated control-code, glyph, Japanese-residue, RMD compilation and CPK validation.

The resulting translation corpus is a mixed-provenance derivative localization: existing upstream translation work plus independent machine-completed text. Do not assume third-party translation text is covered by the code license below.

## Code license

New build/orchestration code in this repository is provided under the MIT License in `LICENSE-CODE`, except where a file clearly originates from or incorporates a third-party project. Third-party rights remain with their respective owners.
