# Release notes — v1.0

## Headline

First public rough-complete text release of this independent Phantasy Star Nova English completion.

## What changed from the public partial patch

- Completed the remaining known untranslated runtime text corpus.
- Closed Story 3, Story 4, NPC and credits queues.
- Built and validated 24,850 enabled English RMDs.
- Reconstructed the required glyph map for all used English/ruby characters.
- Built a complete English overlay and a Vita3K full-merge path.
- Added deterministic hash-gated build tooling.
- Runtime-tested the resulting full English CPK in Vita3K.
- Confirmed continued English operation with game update v1.05 active.

## Metrics

```text
Repository records:                 25,318
Enabled English runtime records:    24,850
Translation queue:                       0
Compile failures:                        0
Visible Japanese residue (audited):      0
Verified final CPK SHA-256:
ebf2cea4c8158f32557d52c58b111101c1818157d862cd7b1c570b096730e4ba
```

## Scope

This is a **rough-complete / machine-completed English text release**. It prioritizes complete playable English access over literary polish. Human editing and full-playthrough QA are welcome future work.

## Known runtime issue

Vita3K may show CAST player-character body rendering glitches. See `KNOWN_ISSUES.md`.
