# Phantasy Star Nova — Complete English Text Build

An independent **AI-assisted completion** of the public Phantasy Star Nova English patch for PlayStation Vita (`PCSG00351`).

This project retains the existing work in the public Arks-Layer translation corpus and machine-translates/completes the previously uncovered text layer. It is **not an official Sega/tri-Ace release and is not endorsed by Arks-Layer**.

![Runtime English dialogue](screenshots/01_rietheia_delta_valiant.png)

## Current status

**Playable English build confirmed in Vita3K.**

- Repository records audited: **25,318**
- Enabled + nonempty English runtime records: **24,850**
- Translation queue: **0**
- Compile result: **24,850 / 24,850**
- Compile failures: **0**
- User-visible untranslated Japanese in the audited enabled corpus: **0**
- Full-merge CPK structural validation: **PASS**
- Vita3K boot: **PASS**
- English visible in gameplay: **PASS**
- Game update **v1.05**: tested and English remained functional
- Manual runtime test performed: early-game/story gameplay, approximately 20 minutes
- Full start-to-finish human playthrough: **not yet claimed**

The completeness claim in this repository refers to the **known audited runtime text corpus**, not to a claim that a human tester has manually visited every branch, quest, DLC path, or text box.

## Why this repository does not contain the game

No full game CPK, PKG, ROM, license, `eboot.bin`, or other original game image is distributed here.

The builder requires you to provide:

1. your own clean `NOVA_FileList_Vita.cpk` from Phantasy Star Nova; and
2. the public Arks-Layer partial English patch, used as a source for patch-only RMD templates.

The project then compiles the completed English text and builds the verified Vita3K replacement CPK locally.

## Quick build

Requirements: **Python 3** and enough free disk space for roughly 10 GB of temporary/output data.

```powershell
python .\tools\build_complete_vita3k.py `
  --app "C:\path\to\NOVA_FileList_Vita.cpk" `
  --public-patch "C:\path\to\ArksLayerPatch.zip" `
  --output ".\NOVA_FileList_Vita_FULL_ENGLISH.cpk"
```

The verified output is:

```text
Size:    3,252,228,483 bytes
SHA-256: ebf2cea4c8158f32557d52c58b111101c1818157d862cd7b1c570b096730e4ba
```

See [BUILD.md](BUILD.md) and [INSTALL_VITA3K.md](INSTALL_VITA3K.md).

## Runtime evidence

Additional screenshots are under [`screenshots/`](screenshots/). The screenshots show live English story dialogue rendered by the full-merge build in Vita3K.

See [QA_EVIDENCE.md](QA_EVIDENCE.md) for what has and has not been proven.

## Known Vita3K graphics issue

On the test machine, a **CAST player character** can render with black/glitched body materials in Vita3K. Disabling **Disable Surface Sync** restored the clothing but the CAST body could remain black. NPCs, environments, UI and English text continued to render correctly. See [KNOWN_ISSUES.md](KNOWN_ISSUES.md).

For clean capture footage, use a non-CAST character if your Vita3K setup shows the same emulator-side issue.

## Upstream and credits

This project is built on the public technical and translation foundation created by **Arks-Layer / PSNovaTranslations**. Their project page describes the public patch as unfinished and links its translation repository.

- Arks-Layer Nova page: https://arks-layer.com/nova.php
- Upstream translation repository: https://github.com/Arks-Layer/PSNovaTranslations
- Vita3K: https://vita3k.org/

The upstream repository asks contributors not to submit AI-generated translations. This independent completion is therefore **not presented as an upstream contribution or pull request**.

See [RIGHTS_AND_ATTRIBUTION.md](RIGHTS_AND_ATTRIBUTION.md).

## Release state

This package is suitable for an initial public **v1.0 / rough-complete text release** because the game boots, plays, and displays the completed English text layer. Further human editing and full-playthrough QA can continue as later releases without reopening the translation-completeness milestone.
