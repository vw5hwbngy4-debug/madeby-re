PHANTASY STAR NOVA — VITA3K FULL-MERGE BUILD v0.1
PASS 12

STATUS
======
STATIC BUILD: PASS
RUNTIME: READY_FOR_VITA3K_TEST

This build has NOT yet been claimed booted or runtime-verified.

WHY THIS BUILD EXISTS
=====================
The prior Pass 11 English CPK was a rePatch/overlay container with 28,115 files. Renaming that overlay to NOVA_FileList_Vita.cpk and replacing the original full APP container caused a black screen before the intro in Vita3K.

The original Japanese APP CPK contains 87,268 files, so the Pass 12 build keeps the complete APP container and merges the English RMD layer into it instead of substituting the smaller overlay.

BUILD STRATEGY
==============
The safest deterministic strategy found was append-only full merge:

- Keep the original APP ContentOffset unchanged.
- Keep the entire original physical content region byte-for-byte at its original absolute offsets.
- Preserve all 66,338 non-replaced original entries with identical metadata and payload bytes.
- Redirect 20,930 original APP RMD entries to the verified English compiled payloads appended after the original APP content region.
- Add 3,920 English RMDs that existed in the patch/runtime layer but not in the base APP TOC.
- Preserve the original full-APP encrypted @UTF CPK style, header schema, Revision 1, Tvers, 8-byte alignment, filename sort semantics and ETOC structure.

INPUT BASE
==========
Original APP:
NOVA_FileList_Vita.cpk
Size: 2,834,095,024 bytes
SHA-256: ad85c330c3258b0f18f57dcf77736f9fbea89c40b66dfef3fbb5c4daeff77e7a
Files: 87,268
RMD IDs: 21,377

Verified Pass 11 English overlay:
NOVA_FileList_Vita_patch.cpk
Size: 606,683,059 bytes
SHA-256: 887a32c15927c227e989366f28f1624c95d7dbef9d8b781c4a6266040a160d17

Translation DB SHA-256:
3bddc5e284fa616259ec2502d98e1a5c5f785f87743917f9bb6e74b9c8390e4e

Glyph map SHA-256:
f478608ee70a5579252fbcffdae8268e49396be8925dd0183d3383d3b909758a

OUTPUT
======
NOVA_FileList_Vita_FULL_ENGLISH.cpk
Size: 3,252,228,483 bytes
SHA-256: ebf2cea4c8158f32557d52c58b111101c1818157d862cd7b1c570b096730e4ba
Files: 91,188
RMD files: 25,297
English enabled RMDs: 24,850 / 24,850

STATIC VALIDATION
=================
CPK parse: PASS
Original APP paths present: 87,268 / 87,268
English compiled IDs present: 24,850 / 24,850
English payload/structure failures: 0
Direct APP RMD replacements: 20,930
Patch-only RMD additions: 3,920
Non-replaced APP entries: 66,338
Non-replaced metadata failures: 0
Non-replaced payload byte-identity failures: 0
Partial overlap failures: 0
Bounds failures: 0
Alignment failures: 0
ETOC validation: PASS, 91,189 rows
Header size fields: PASS
Translation queue: 0
Empty enabled strings: 0
User-visible Japanese residue: 0

The original APP intentionally contains 15,255 exact-span alias references where multiple filenames point to the same identical physical payload. These were preserved and are not corruption. There are zero partial/invalid payload overlaps.

VITA3K TEST — REPLACE ONLY ONE FILE
====================================
1. Confirm the clean Japanese game still boots.
2. Close Vita3K completely.
3. Back up:
   ux0/app/PCSG00351/NOVA_FileList_Vita.cpk
4. Take NOVA_FileList_Vita_FULL_ENGLISH.cpk and rename it to:
   NOVA_FileList_Vita.cpk
5. Replace ONLY:
   ux0/app/PCSG00351/NOVA_FileList_Vita.cpk
6. Start Phantasy Star Nova.

DO NOT REPLACE
==============
eboot.bin
sce_sys
sce_module
disc1
license/work.bin
package metadata

DO NOT copy the old rePatch tree over ux0/app.

RESULT CATEGORIES
=================
A. BOOT + ENGLISH
B. BOOT + JAPANESE
C. BOOT + CORRUPT GLYPHS
D. BLACK SCREEN BEFORE INTRO
E. CRASH WITH LOG
F. BOOT BUT SPECIFIC RMD FAILURE

If the result is not A, preserve the Vita3K console/log and take a screenshot of the last visible screen.

LOCAL BUILDER OPTION
====================
If downloading the 3.25 GB CPK is inconvenient, use PSNova_English_Vita3K_FullMerge_Builder_v0.1.zip. It uses the clean 2.83 GB APP CPK already on your PC plus the Pass 11 overlay CPK you already have, and reproduces this exact output. It refuses wrong input hashes and verifies the final SHA-256.
