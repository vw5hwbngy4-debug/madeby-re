# PHANTASY STAR NOVA — VITA3K FULL-MERGE BUILD, PASS 12

## Result

**STATIC PASS. Runtime remains `READY_FOR_VITA3K_TEST`.**

The Pass 11 overlay CPK was not reused as a full APP replacement. Pass 12 instead built a complete Vita3K-targeted CPK from the verified original Japanese APP container plus the frozen 24,850 English compiled RMD payloads.

## Runtime evidence that triggered Pass 12

- Clean Japanese `PCSG00351` install boots in Vita3K.
- Replacing the full `NOVA_FileList_Vita.cpk` with the much smaller Pass 11 patch/overlay CPK caused a black screen before the intro.
- The original APP contains 87,268 files, whereas the overlay contained 28,115 files.

This established a packaging mismatch and justified a full-container merge. It did **not** establish that the English RMD payloads were invalid.

## Inputs

| Input | Size | SHA-256 |
|---|---:|---|
| Original `NOVA_FileList_Vita.cpk` | 2,834,095,024 | `ad85c330c3258b0f18f57dcf77736f9fbea89c40b66dfef3fbb5c4daeff77e7a` |
| Pass 11 overlay `NOVA_FileList_Vita_patch.cpk` | 606,683,059 | `887a32c15927c227e989366f28f1624c95d7dbef9d8b781c4a6266040a160d17` |
| Translation DB | 25,318 records | `3bddc5e284fa616259ec2502d98e1a5c5f785f87743917f9bb6e74b9c8390e4e` |
| Glyph map | 116 normal + 26 ruby required mappings | `f478608ee70a5579252fbcffdae8268e49396be8925dd0183d3383d3b909758a` |

## Mapping

- Enabled compiled English RMDs: **24,850**
- Direct replacements where the RMD already exists in APP: **20,930**
- Patch-only English RMD additions absent from APP: **3,920**
- Unresolved enabled IDs: **0**

The final TOC contains every original APP filename plus the 3,920 required patch-only RMD filenames.

## Compatibility-oriented build strategy

Instead of repacking every 2.8 GB asset into a new physical ordering, Pass 12 uses an append-only merge:

1. The original APP `ContentOffset` remains `5,041,304`.
2. The complete original physical content region remains byte-identical and at identical absolute offsets.
3. All non-replaced original TOC entries retain their original `FileOffset`, `FileSize`, `ExtractSize`, and CPK ID.
4. The 24,850 frozen English RMD payloads are appended after the original content region.
5. TOC entries for the 20,930 replaced APP RMDs are redirected to the appended English payloads.
6. 3,920 patch-only English RMD entries are added with new IDs.
7. The original APP CPK dialect is retained: encrypted CRI `@UTF`, chunk flag `0`, Revision `1`, `CPKMC2.30.07, DLL3.00.07`, alignment `8`.
8. Original ETOC rows are retained by original CPK ID; additions receive their corresponding overlay timestamps.

The expanded TOC is 4,844,650 bytes and still fits before the unchanged original content base, leaving 194,606 bytes of the original pre-content zero reserve.

## Output

`NOVA_FileList_Vita_FULL_ENGLISH.cpk`

- Size: **3,252,228,483 bytes**
- SHA-256: **`ebf2cea4c8158f32557d52c58b111101c1818157d862cd7b1c570b096730e4ba`**
- Files: **91,188**
- RMD files: **25,297**
- ETOC rows: **91,189**
- Content size: **3,246,457,568 bytes**

## Validation

- CPK parse: **PASS**
- Original APP paths preserved: **87,268 / 87,268**
- Compiled enabled English payloads: **24,850 / 24,850**
- English payload/hash/structural failures: **0**
- Non-replaced original entries: **66,338**
- Non-replaced metadata failures: **0**
- Non-replaced byte-identity failures: **0**
- Bounds failures: **0**
- Alignment failures: **0**
- Invalid partial overlaps: **0**
- ETOC: **PASS**
- Header size fields: **PASS**
- Translation queue: **0**
- Empty enabled: **0**
- User-visible Japanese: **0**

The original APP contains 15,255 intentional exact-span payload aliases. These remain valid and were distinguished from invalid partial overlaps.

## Deterministic reproduction test

A separate portable builder was run against the verified clean APP + Pass 11 overlay. It reproduced a second CPK with:

- Size: **3,252,228,483 bytes**
- SHA-256: **`ebf2cea4c8158f32557d52c58b111101c1818157d862cd7b1c570b096730e4ba`**
- Byte comparison against the first Pass 12 output: **IDENTICAL**

## Runtime gate

No runtime success is claimed yet. The next operation is deliberately one-file-only:

`ux0/app/PCSG00351/NOVA_FileList_Vita.cpk`

must be backed up and replaced with the Pass 12 full merge, while leaving the known-working original Vita3K `eboot.bin` and all other installed files untouched.
