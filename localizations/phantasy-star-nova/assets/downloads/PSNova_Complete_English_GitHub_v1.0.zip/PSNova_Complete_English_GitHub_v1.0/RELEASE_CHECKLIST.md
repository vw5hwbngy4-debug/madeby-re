# GitHub / public release checklist

- [ ] Create GitHub repository.
- [ ] Upload the contents of this ZIP to the repository root.
- [ ] Confirm `README.md` renders with screenshots.
- [ ] Tag `v1.0`.
- [ ] Create GitHub Release using `RELEASE_NOTES.md`.
- [ ] Do **not** attach the 3.25 GB full game CPK.
- [ ] Optionally attach this repository ZIP as a source package.
- [ ] Add the final YouTube gameplay proof URL to README.
- [ ] Add the Wolken project page URL to README.
- [ ] Add the X announcement URL to README.
- [ ] Preserve the verified SHA-256 values.
- [ ] Keep the CAST/Vita3K issue visible under Known Issues.
- [ ] Avoid claiming a full manual playthrough until one is documented.
