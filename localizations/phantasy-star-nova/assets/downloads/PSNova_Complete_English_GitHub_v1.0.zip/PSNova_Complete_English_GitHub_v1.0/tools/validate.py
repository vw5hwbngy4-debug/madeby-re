#!/usr/bin/env python3
import json,re,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent; db=json.load(open(root/'corpus/translations.json',encoding='utf-8-sig'))
jp=re.compile(r'[\u3040-\u30ff\u3400-\u9fff]'); bad=[]
for k,v in db.items():
    if jp.search(v.get('OriginalText','')) and (not v.get('Enabled') or not v.get('Text') or jp.search(v.get('Text',''))): bad.append(k)
print(f'records={len(db)} remaining={len(bad)}')
sys.exit(1 if bad else 0)
