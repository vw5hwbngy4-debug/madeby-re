# Technical summary

The public patch is an overlay CPK. Replacing the full Vita3K APP CPK with that smaller overlay causes a black screen because the overlay does not contain the complete game asset set.

The working Vita3K strategy is therefore:

```text
clean full APP CPK
+ completed English runtime RMDs
+ patch-only RMD runtime entries
= full replacement Vita3K CPK
```

Pass 12 verified that all original APP entries are retained while English RMDs are replaced/added.

Verified final full merge:

```text
Files: 91,188
English RMDs: 24,850
Size: 3,252,228,483 bytes
SHA-256: ebf2cea4c8158f32557d52c58b111101c1818157d862cd7b1c570b096730e4ba
```

The separate official game update v1.05 remains in Vita3K's `ux0/patch/PCSG00351` layer and was runtime-tested successfully with the full-English base CPK.
