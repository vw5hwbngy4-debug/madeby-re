# External references

- Arks-Layer Phantasy Star Nova English patch: https://arks-layer.com/nova.php
- Arks-Layer PSNovaTranslations: https://github.com/Arks-Layer/PSNovaTranslations
- Vita3K: https://vita3k.org/
- Vita3K Phantasy Star Nova character-creation/Vulkan issue #4088: https://github.com/Vita3K/Vita3K/issues/4088
