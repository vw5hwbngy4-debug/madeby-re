# Build

## Inputs

The builder deliberately does not ship original game assets.

You need:

- Python 3.10+ recommended.
- A clean base-game `NOVA_FileList_Vita.cpk` from `PCSG00351`.
- The **public Arks-Layer English partial patch** ZIP/CPK. Do **not** substitute the official Phantasy Star Nova v1.05 game-update CPK for this input.
- About 10 GB free space is recommended for canonical RMD templates, compiled RMDs, intermediate overlay and the final full CPK.

Expected clean base CPK:

```text
Size: 2,834,095,024 bytes
SHA-256: ad85c330c3258b0f18f57dcf77736f9fbea89c40b66dfef3fbb5c4daeff77e7a
```

Expected public partial English patch CPK:

```text
SHA-256: 50c733ec4ab5ccc57c6d7e1e0f30d6b8dca2f0ad8104a00f31ca33294bd0466a
```

The wrapper refuses unexpected hashes.

## One-command build

```powershell
python .\tools\build_complete_vita3k.py `
  --app "C:\path\to\NOVA_FileList_Vita.cpk" `
  --public-patch "C:\path\to\patch.zip" `
  --output ".\NOVA_FileList_Vita_FULL_ENGLISH.cpk"
```

`--public-patch` may also point directly to the public `NOVA_FileList_Vita_patch.cpk`.

Add `--keep-work` if you want to keep generated canonical templates, compiled RMDs and the completed overlay for inspection.

## What the wrapper does

1. Verifies the clean APP CPK.
2. Extracts/verifies the public partial English patch CPK.
3. Creates a temporary repository index from this release's `corpus/rmd/*.json`.
4. Reconstructs canonical RMD templates with **PATCH-first, APP-second** precedence.
5. Compiles **24,850** enabled English RMD records with the reconstructed glyph map.
6. Builds the complete English overlay CPK.
7. Verifies that overlay against the Pass 11 SHA-256.
8. Full-merges the English RMDs into the original complete APP CPK for Vita3K.
9. Verifies byte-identical output against the Pass 12 hash.

## Verified result

```text
NOVA_FileList_Vita_FULL_ENGLISH.cpk
Size: 3,252,228,483 bytes
SHA-256: ebf2cea4c8158f32557d52c58b111101c1818157d862cd7b1c570b096730e4ba
Files: 91,188
English enabled RMDs: 24,850
```

The build intentionally preserves the clean base game as the source for all unrelated assets.
