# QA and runtime evidence

## Proven by static audit

- 25,318 repository records inventoried.
- 24,850 records enabled with nonempty English text.
- Translation queue: 0.
- Empty enabled records: 0.
- User-visible untranslated Japanese in enabled audited text: 0.
- 24,850 / 24,850 intended RMDs compiled.
- Compile failures: 0.
- RMD structural validation failures: 0.
- Full Vita3K CPK parse: PASS.
- Expected English runtime IDs present: 24,850 / 24,850.
- CPK bounds/alignment validation: PASS.

## Proven by runtime test

On 29 August 2026:

- Phantasy Star Nova booted in Vita3K with the full-merge English CPK.
- Story dialogue displayed in English.
- Approximately 20 minutes of early gameplay were played/recorded.
- Multiple story scenes rendered correctly with English text.
- The game remained English after installing/activating game update v1.05.
- No translation-related crash was observed during that test session.

Screenshots in this repository are direct runtime captures from that test.

## Not yet claimed

- No human has yet documented a complete start-to-finish playthrough of this release.
- Every optional quest/DLC branch has not been manually visited.
- Every text box has not been visually inspected for stylistic polish or overflow.
- Machine-completed English is intentionally a rough-complete localization, not a claim of professional literary editing.

## Recommended future QA

Future releases can add full-playthrough evidence, late-game screenshots, overflow fixes and human copyediting without changing the current corpus-completeness result.
